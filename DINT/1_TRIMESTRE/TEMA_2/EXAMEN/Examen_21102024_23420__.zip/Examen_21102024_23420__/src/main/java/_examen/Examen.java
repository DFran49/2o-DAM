package _examen; 

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * Nombre alumn@:
 */
public class Examen extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {

        VBox vbox=new VBox(10); 
        vbox.setPadding(new Insets(20));
        Scene scene=new Scene(vbox, 500,400);
        primaryStage.setScene(scene);
        primaryStage.setTitle("NOMBRE ALUMNO");
        primaryStage.show();
    }

}
