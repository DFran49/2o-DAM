/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.fcm.pokeTeams;

/**
 *
 * @author DFran49
 */
import com.fcm.pokeTeams.modelos.Equipo;
import com.fcm.pokeTeams.modelos.Miembro;
import com.fcm.pokeTeams.util.Conexion;
import com.fcm.pokeTeams.util.Utilidades;
import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.ContextMenuEvent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

public class controllerEquipos implements Initializable {
    private controllerEquipo ce;
    Stage emergente;
    Conexion conexion = null;
    Utilidades util = new Utilidades();
    List<Miembro> participantes = new ArrayList<>();
    Equipo equipo;

    @FXML
    private ImageView imgPokemon1;

    @FXML
    private ImageView imgPokemon2;

    @FXML
    private ImageView imgPokemon3;

    @FXML
    private ImageView imgPokemon4;

    @FXML
    private ImageView imgPokemon5;

    @FXML
    private ImageView imgPokemon6;

    @FXML
    private Label txtFormatoEquipo;

    @FXML
    private Label txtNombreEquipo;

    @FXML
    void abrirEquipo(MouseEvent event) {
        this.ce.enviaMiembros(participantes, txtNombreEquipo.getText());
        this.emergente.show();
    }

    @FXML
    void abrirMenu(ContextMenuEvent event) {
        
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        Parent rootEquipo = null;
        FXMLLoader loaderEquipo = new FXMLLoader(getClass().getResource("fxml/emergente_añadir_equipo_v1.fxml"));
        try {
            rootEquipo = loaderEquipo.load();
        } catch (IOException ex) {
            System.err.println(ex.getMessage());
        }

        ce = loaderEquipo.getController();
        ce.setControladorEnlace(this);

        Scene sceneB = new Scene(rootEquipo);
        emergente = new Stage();
        emergente.setResizable(false);
        emergente.setScene(sceneB);
        emergente.setTitle("Ventana Emergente");
    }

    public void asignarEquipo(Equipo e, Conexion c) {
        txtNombreEquipo.setText(e.getNombre());
        txtFormatoEquipo.setText(e.getFormato());
        
        try {
            String query = "SELECT N_Pokedex, Mote, Genero, Nivel, Habilidad, Naturaleza, Objeto, Movimientos, EVs, IVs, Sprite "
                    + "FROM equipo JOIN pokemon USING (N_Pokedex) WHERE ID_Equipo = " + e.getIdEquipo();
            Statement statement = conexion.getConexion().createStatement();
            ResultSet result = statement.executeQuery(query);
            while (result.next()) {
                Miembro tempMiembro = new Miembro();
                tempMiembro.setnPokedex(result.getInt("N_Pokedex"));
                tempMiembro.setMote(result.getString("Mote"));
                System.out.println(tempMiembro.getMote());
                tempMiembro.setGenero(result.getString("Genero").charAt(0));
                tempMiembro.setNivel(result.getInt("Nivel"));
                tempMiembro.setHabilidad(result.getString("Habilidad"));
                tempMiembro.setNaturaleza(result.getString("Naturaleza"));
                tempMiembro.setObjeto(result.getString("Objeto"));
                tempMiembro.setMovimientos(result.getString("Movimientos"));
                tempMiembro.setEvs(result.getString("EVs"));
                tempMiembro.setIvs(result.getString("IVs"));
                tempMiembro.setSprite(result.getString("Sprite"));
                participantes.add(tempMiembro);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(controllerEquipos.class.getName()).log(Level.SEVERE, null, ex);
        }
        List<ImageView> listImagenes = new ArrayList<>();
        listImagenes.add(imgPokemon1);
        listImagenes.add(imgPokemon2);
        listImagenes.add(imgPokemon3);
        listImagenes.add(imgPokemon4);
        listImagenes.add(imgPokemon5);
        listImagenes.add(imgPokemon6);
        
        for (int i = 0; i < participantes.size(); i++) {
            util.recuperarImagenBBDD(participantes.get(i).getSprite(), listImagenes.get(i));
        }
        
        equipo = e;
        conexion = c;
    }
}
