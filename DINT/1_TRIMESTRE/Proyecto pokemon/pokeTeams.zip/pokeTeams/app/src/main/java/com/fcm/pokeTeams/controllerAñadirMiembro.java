/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.fcm.pokeTeams;

/**
 *
 * @author DFran49
 */
import com.fcm.pokeTeams.modelos.Miembro;
import com.fcm.pokeTeams.util.Utilidades;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;

public class controllerAñadirMiembro implements Initializable {
    private controllerTarjetaMiembro ctm;
    Utilidades util = new Utilidades();
    private Miembro miembro;

    @FXML
    private ComboBox<?> cbEspecie;

    @FXML
    private ComboBox<?> cbGenero;

    @FXML
    private ComboBox<?> cbHabilidad;

    @FXML
    private ImageView imgPokemon;

    @FXML
    private Slider sdEVsAtk;

    @FXML
    private Slider sdEVsDef;

    @FXML
    private Slider sdEVsHp;

    @FXML
    private Slider sdEVsSpA;

    @FXML
    private Slider sdEVsSpD;

    @FXML
    private Slider sdEVsSpe;

    @FXML
    private Slider sdIVsAtk;

    @FXML
    private Slider sdIVsDef;

    @FXML
    private Slider sdIVsHp;

    @FXML
    private Slider sdIVsSpA;

    @FXML
    private Slider sdIVsSpD;

    @FXML
    private Slider sdIVsSpe;

    @FXML
    private Label txtEVsAtk;

    @FXML
    private Label txtEVsDef;

    @FXML
    private Label txtEVsHp;

    @FXML
    private Label txtEVsSpA;

    @FXML
    private Label txtEVsSpD;

    @FXML
    private Label txtEVsSpe;

    @FXML
    private TextField txtEspecie;

    @FXML
    private Label txtIVsAtk;

    @FXML
    private Label txtIVsDef;

    @FXML
    private Label txtIVsHp;

    @FXML
    private Label txtIVsSpA;

    @FXML
    private Label txtIVsSpD;

    @FXML
    private Label txtIVsSpe;

    @FXML
    private TextField txtMote;

    @FXML
    private TextField txtMovimiento1;

    @FXML
    private TextField txtMovimiento2;

    @FXML
    private TextField txtMovimiento3;

    @FXML
    private TextField txtMovimiento4;

    @FXML
    private TextField txtObjeto;

    @FXML
    void actualizarEVs(MouseEvent event) {

    }

    @FXML
    void actualizarIVs(MouseEvent event) {

    }

    @FXML
    void subirImagen(MouseEvent event) {

    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    }

    void setControladorEnlace(controllerTarjetaMiembro c) {
        ctm = c;
    }
    
    void enviaMiembro(Miembro m) {
        //miembro = m;
        //txtEspecie.setText(m.getE);
        //configurar
        txtMote.setText(m.getMote());
        util.recuperarImagenBBDD(m.getSprite(), imgPokemon);
        //leerHabilidades(p);
        //leerStats(p);
    }
}

