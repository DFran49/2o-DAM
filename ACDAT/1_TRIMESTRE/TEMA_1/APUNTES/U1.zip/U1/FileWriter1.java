package U1;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
import java.io.FileWriter;
import java.io.IOException;

public class FileWriter1 {
    public static void main(String[] args) {
        String fileName = "archivo.txt"; // Definir el nombre del archivo

        // Uso de try-with-resources para manejo automático de recursos
        try (FileWriter writer = new FileWriter(fileName)) { // Crear el flujo de salida
            // Escribir caracteres usando varios métodos
            writer.write('H');
            writer.write("ola, ");
            writer.write(new char[] { 'm', 'u', 'n', 'd', 'o' });
            writer.write("! **");
            writer.append ('*');

            // Agregar una nueva línea usando el separador de línea del sistema
            writer.write(System.lineSeparator());

            // Usar flush para asegurarse de que los datos se escriban en el archivo
            writer.flush();

            System.out.println("Se ha escrito en el archivo correctamente.");
        } catch (IOException e) {
            System.err.println("Ocurrió un error al escribir en el archivo: " + e.getMessage());
        }
    }
}
