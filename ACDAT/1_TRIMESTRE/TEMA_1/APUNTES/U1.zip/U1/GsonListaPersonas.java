package U1;

import com.google.gson.Gson;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

class Persona7 {
    private String nombre;
    private int edad;

    public Persona7(String nombre, int edad) {
        this.nombre = nombre;
        this.edad = edad;
    }

    public String getNombre() { return nombre; }
    public int getEdad() { return edad; }
}

public class GsonListaPersonas {
    private List<Persona7> personas = new ArrayList<>();

    public List<Persona7> getPersonas() { return personas; }

    public static void main(String[] args) {
        GsonListaPersonas listaPersonas = new GsonListaPersonas();
        listaPersonas.getPersonas().add(new Persona7("Ana", 30));
        listaPersonas.getPersonas().add(new Persona7("Carlos", 25));

        Gson gson = new Gson();

        try (FileWriter writer = new FileWriter("personas.json")) {
            gson.toJson(listaPersonas, writer);
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }

        try (FileReader reader = new FileReader("personas.json")) {
            GsonListaPersonas listaPersonasLeido = gson.fromJson(reader, GsonListaPersonas.class);
            listaPersonasLeido.getPersonas().forEach(p -> System.out.println(p.getNombre() + " - " + p.getEdad()));
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
