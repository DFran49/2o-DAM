package U1;

import java.io.*;
import java.nio.file.FileSystems;

public class PropiedadesDelSistema {
    public static void main(String[] args) {
        // Obtener y mostrar algunas propiedades del sistema
        String fileSeparator = FileSystems.getDefault().getSeparator();
        String userHome = System.getProperty("user.home");
        String userDir = System.getProperty("user.dir");
        String lineSeparator = System.lineSeparator();

        System.out.println("Separador de directorios: " + fileSeparator);
        System.out.println("Directorio de inicio del usuario: " + userHome);
        System.out.println("Directorio de trabajo actual: " + userDir);
        System.out.println("Separador de línea: " + lineSeparator.replace("\n", "\\n").replace("\r", "\\r"));

        // Crear una ruta de acceso al directorio de inicio del usuario
        String filePath = userHome + fileSeparator + "miarchivo.txt";

        // Crear y escribir en un fichero con el formato adecuado para el sistema
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            writer.write("Este es un ejemplo de línea 1" + lineSeparator);
            writer.write("Este es un ejemplo de línea 2" + lineSeparator);
            writer.write("Este es un ejemplo de línea 3" + lineSeparator);
            System.out.println("Datos escritos en el fichero: " + filePath);
        } catch (IOException e) {
            System.err.println("Error al escribir en el fichero: " + e.getMessage());
        }

        // Leer el fichero y mostrar su contenido
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String linea;
            System.out.println("Contenido del fichero:");
            while ((linea = reader.readLine()) != null)
                System.out.println(linea);
        } catch (IOException e) {
            System.err.println("Error al leer el fichero: " + e.getMessage());
        }
    }
}
