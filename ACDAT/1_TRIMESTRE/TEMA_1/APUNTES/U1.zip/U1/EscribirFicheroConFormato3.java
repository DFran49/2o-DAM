package U1;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class EscribirFicheroConFormato3 {
    // Definir una constante para el formato de las líneas
    private static final String FORMATO_LINEA = "%-10s      %8.2f      %6d%n";

    public static void main(String[] args) {
        String archivoSalida = "salida.txt";

        // Manejo de recursos con try-with-resources
        try (PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(archivoSalida)))) {
            pw.println("Artículo       Precio/Kg.      Nº Kg.");
            pw.println("-------------------------------------");
            pw.printf(FORMATO_LINEA, "Tomates", 1.5, 10);
            pw.printf(FORMATO_LINEA, "Judías", 3.75, 2);
            pw.printf(FORMATO_LINEA, "Pimientos", 1.85, 6);

            System.out.println("Archivo de salida creado con éxito.");
        } catch (IOException e) {
            System.err.println("Error al escribir en el archivo: " + e.getMessage());
        }
    }
}
