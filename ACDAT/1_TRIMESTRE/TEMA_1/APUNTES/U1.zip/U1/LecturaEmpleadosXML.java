package U1;

import org.w3c.dom.*;
import javax.xml.parsers.*;
import java.io.File;

public class LecturaEmpleadosXML {
    public static void main(String[] args) {
        File inputFile = new File("empleados.xml");

        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.parse(inputFile);
            document.getDocumentElement().normalize();

            System.out.printf("Elemento raíz: %s %n", document.getDocumentElement().getNodeName());

            NodeList empleados = document.getElementsByTagName("empleado");
            System.out.printf("Nodos empleado a recorrer: %d %n", empleados.getLength());

            for (int i = 0; i < empleados.getLength(); i++) {
                Node empleado = empleados.item(i);
                if (empleado.getNodeType() == Node.ELEMENT_NODE) {
                    Element elemento = (Element) empleado;
                    System.out.printf("ID = %s %n", getTextContent(elemento, "id"));
                    System.out.printf(" - Nombre = %s %n", getTextContent(elemento, "nombre"));
                    System.out.printf(" - Apellidos = %s %n", getTextContent(elemento, "apellidos"));
                    System.out.printf(" - Departamento = %s %n", getTextContent(elemento, "departamento"));
                    System.out.printf(" - Sueldo = %s %n", getTextContent(elemento, "sueldo"));
                }
            }
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
        }
    }

    private static String getTextContent(Element element, String tagName) {
        NodeList nodeList = element.getElementsByTagName(tagName);
        if (nodeList.getLength() > 0) {
            return nodeList.item(0).getTextContent();
        }
        return "N/A";
    }
}
