package U1;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

class Persona4 {
    private String nombre;
    private int edad;

    @JsonCreator
    public Persona4(@JsonProperty("nombre") String nombre, @JsonProperty("edad") int edad) {
        this.nombre = nombre;
        this.edad = edad;
    }

    @JsonProperty("nombre")
    public String getNombre() { return nombre; }

    @JsonProperty("edad")
    public int getEdad() { return edad; }
}

public class JSONListaPersonas {
    private List<Persona4> personas = new ArrayList<>();

    public List<Persona4> getPersonas() { return personas; }

    public static void main(String[] args) {
        JSONListaPersonas listaPersonas = new JSONListaPersonas();
        listaPersonas.getPersonas().add(new Persona4("Ana", 30));
        listaPersonas.getPersonas().add(new Persona4("Carlos", 25));

        ObjectMapper objectMapper = new ObjectMapper();

        try {
            objectMapper.writeValue(new File("personas.json"), listaPersonas);
            JSONListaPersonas containerLeido = objectMapper.readValue(new File("personas.json"), new TypeReference<>() {});
            containerLeido.getPersonas().forEach(p -> System.out.println(p.getNombre() + " - " + p.getEdad()));
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
