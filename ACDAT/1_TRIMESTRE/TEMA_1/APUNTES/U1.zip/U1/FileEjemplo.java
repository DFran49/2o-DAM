package U1;

import java.io.File;
import java.io.IOException;

public class FileEjemplo {
    public static void main(String[] args) {
        // Crear una instancia de File para representar un fichero
        File archivo = new File("archivo.txt"); // Windows C:\\directorio\\nombre_fichero.ext
        // Linux /directorio/nombre_fichero.ext
        // Verificar si el archivo existe
        if (archivo.exists())
            System.out.println("El archivo existe.");
        else
            System.out.println("El archivo no existe.");

        // Crear un nuevo archivo
        try {
            boolean creado = archivo.createNewFile();
            if (creado)
                System.out.println("Archivo creado correctamente.");
            else
                System.out.println("El archivo ya existe o no se pudo crear.");
        } catch (IOException e) {
            System.out.println("Ocurrió un error al crear el archivo: " + e.getMessage());
        }

        // Obtener información sobre el archivo
        System.out.println("Nombre del archivo: " + archivo.getName());
        System.out.println("Ruta absoluta: " + archivo.getAbsolutePath());
        System.out.println("Tamaño del archivo: " + archivo.length() + " bytes");

        // Eliminar el archivo
        boolean eliminado = archivo.delete();
        if (eliminado)
            System.out.println("Archivo eliminado.");
        else
            System.out.println("No se pudo eliminar el archivo o el archivo no existe.");
    }
}
