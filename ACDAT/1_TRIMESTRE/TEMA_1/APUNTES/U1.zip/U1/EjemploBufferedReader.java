package U1;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class EjemploBufferedReader {
    public static void main(String[] args) {
        String rutaArchivo = "archivo.txt";

        // Uso de try-with-resources para asegurar el cierre del BufferedReader
        try (BufferedReader bufferLector = new BufferedReader(new FileReader(rutaArchivo))) {
            String linea;
            int numeroLinea = 1;

            System.out.println("--- Lectura de líneas ---");
            while ((linea = bufferLector.readLine()) != null) // Leer el archivo línea a línea
                System.out.printf("Línea %d: %s%n", numeroLinea++, linea);
        } catch (IOException e) {
            System.err.printf("Error al leer el archivo '%s': %s%n", rutaArchivo, e.getMessage());
        }
    }
}
