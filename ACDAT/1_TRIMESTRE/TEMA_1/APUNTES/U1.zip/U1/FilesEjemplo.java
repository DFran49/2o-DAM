package U1;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;

public class FilesEjemplo {
    public static void main(String[] args) {
        // Definir las rutas de acceso de origen y destino
        Path origen = Paths.get("origen.txt");
        Path destino = Paths.get("destino.txt");
        Path nuevoDestino = Paths.get("otro_destino.txt");

        try {
            // Crear un nuevo fichero en el directorio actual
            if (!Files.exists(origen)) {
                Files.createFile(origen);
                System.out.println("Fichero de origen creado.");
            }

            // Escribir datos en el fichero
            String contenido = "Este es el contenido del fichero.";
            Files.writeString(origen, contenido);
            System.out.println("Datos escritos en el fichero de origen.");

            // Leer los bytes del fichero
            String contenidoLeido = Files.readString(origen, StandardCharsets.UTF_8);
            System.out.println("Contenido leído del fichero: " + contenidoLeido);

            // Copiar el fichero al directorio de destino
            Files.copy(origen, destino, StandardCopyOption.REPLACE_EXISTING);
            System.out.println("Fichero copiado con éxito.");

            // Mover el fichero a otro directorio
            Files.move(destino, nuevoDestino, StandardCopyOption.REPLACE_EXISTING);
            System.out.println("Fichero movido con éxito.");

            // Comprobar si el fichero de origen es un fichero regular
            boolean esFichero = Files.isRegularFile(origen, LinkOption.NOFOLLOW_LINKS);
            System.out.println("¿El fichero de origen es un fichero regular? " + esFichero);

            // Comprobar si el nuevo destino es un fichero
            boolean esDirectorio = Files.isDirectory(nuevoDestino, LinkOption.NOFOLLOW_LINKS);
            System.out.println("¿El nuevo destino es un directorio? " + esDirectorio);

            // Eliminar el fichero de origen y el nuevo destino
            Files.deleteIfExists(origen);
            Files.deleteIfExists(nuevoDestino);
            System.out.println("Fichero de origen y nuevo destino eliminados.");
        } catch (IOException e) {
            System.err.println("Se produjo un error: " + e.getMessage());
        }
    }
}
