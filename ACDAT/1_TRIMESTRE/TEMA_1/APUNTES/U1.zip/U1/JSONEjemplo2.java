package U1;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JSONEjemplo2 {
    public static void main(String[] args) {
        ObjectMapper objectMapper = new ObjectMapper();
        Persona3 persona = new Persona3("María", 30);

        try {
            String jsonString = objectMapper.writeValueAsString(persona);
            System.out.println(jsonString);
        } catch (JsonProcessingException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}

class Persona3 {
    @JsonProperty("nombre")
    private String nombre;
    @JsonProperty("edad")
    private int edad;

    public Persona3(String nombre, int edad) {
        this.nombre = nombre;
        this.edad = edad;
    }
}
