package U1;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class FileCreationAndWriteEjemplo {
    public static void main(String[] args) {
        String fileName = "texto.txt"; // Nombre del archivo
        String contenido = "Este es el contenido del archivo."; // Contenido a escribir

        try { // Manejo de la creación y escritura del archivo
            File file = new File(fileName);

            if (file.createNewFile()) { // Crear un nuevo archivo si no existe
                System.out.println("Archivo creado: " + fileName);
            } else {
                clearFileContent(file); // Limpiar contenido del archivo existente
                System.out.println("Contenido del archivo existente borrado.");
            }

            writeToFile(file, contenido); // Escribir contenido en el archivo
            System.out.println("Contenido escrito en el archivo.");
        } catch (IOException e) {
            System.err.println("Error al manipular el archivo: " + e.getMessage());
        }
    }

    // Método para limpiar el contenido de un archivo
    private static void clearFileContent(File file) throws IOException {
        try (FileWriter fw = new FileWriter(file)) {
            fw.write(""); // Escribir una cadena vacía para borrar el contenido
        }
    }

    // Método para escribir contenido en un archivo utilizando BufferedWriter
    private static void writeToFile(File file, String contenido) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, true))) {
            writer.write(contenido);
            writer.newLine(); // Añadir una nueva línea después del contenido
        }
    }
}
