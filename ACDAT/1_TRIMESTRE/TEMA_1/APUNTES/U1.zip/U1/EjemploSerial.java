package U1;

import java.io.*;
import java.util.Date;

public class EjemploSerial {
    public static void main(String[] args) {
        // Serialización de objetos
        try (FileOutputStream archivo = new FileOutputStream("prueba.dat");
             ObjectOutputStream salida = new ObjectOutputStream(archivo)) {
            salida.writeObject("Hoy es: ");
            salida.writeObject(new Date());
        } catch (IOException e) {
            System.out.println("Error al escribir en el archivo: " + e.getMessage());
        }

        // Deserialización de objetos
        try (FileInputStream archivo = new FileInputStream("prueba.dat");
             ObjectInputStream entrada = new ObjectInputStream(archivo)) {
            String hoy = (String) entrada.readObject();
            Date fecha = (Date) entrada.readObject();
            System.out.println(hoy + fecha);
        } catch (FileNotFoundException e) {
            System.out.println("No se pudo abrir el archivo: " + e.getMessage());
        } catch (IOException e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
        } catch (ClassNotFoundException e) {
            System.out.println("Clase no encontrada durante la deserialización: " + e.getMessage());
        }
    }
}
