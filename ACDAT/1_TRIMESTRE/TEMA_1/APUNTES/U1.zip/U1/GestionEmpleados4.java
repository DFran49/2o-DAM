package U1;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.security.AnyTypePermission;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;

class Utiles4 {
    public static final String ROJO = "\033[31m";
    public static final String VERDE = "\033[32m";
    public static final String AZUL = "\033[34m";
    public static final String MORADO = "\033[35m";
    public static final String RESET = "\033[0m";
    public static final String LIMPIAR_PANTALLA = "\033[2J";

    private static final Scanner SCANNER = new Scanner(System.in);

    public static int leerEnteroValido(String texto) {
        int numero;
        while (true) {
            System.out.print(texto);
            if (SCANNER.hasNextInt()) {
                numero = SCANNER.nextInt();
                SCANNER.nextLine(); // Consumir la nueva línea
                return numero;
            } else {
                System.out.println("Valor no válido. Por favor, ingresa un número entero.");
                SCANNER.nextLine(); // Limpiar el búfer de entrada
            }
        }
    }

    public static double leerDoubleValido(String mensaje) {
        double numero;
        while (true) {
            System.out.print(mensaje);
            if (SCANNER.hasNextDouble()) {
                numero = SCANNER.nextDouble();
                SCANNER.nextLine(); // Consumir la nueva línea
                return numero;
            } else {
                System.out.println("Valor no válido. Por favor, ingresa un número decimal.");
                SCANNER.nextLine(); // Limpiar el búfer de entrada
            }
        }
    }

    public static String leerTextoConLongitudMaxima(String mensaje, int longitudMaxima) {
        String texto;
        while (true) {
            System.out.print(mensaje);
            texto = SCANNER.nextLine();
            if (texto.isEmpty())
                System.out.println("El texto no puede dejarse vacío. Intenta de nuevo.");
            else if (texto.length() > longitudMaxima)
                System.out.println("El texto tiene más de " + longitudMaxima + " caracteres. Intenta de nuevo.");
            else
                return texto;
        }
    }

    public static void pulseIntroParaContinuar() {
        System.out.println("Presione INTRO para continuar...");
        SCANNER.nextLine(); // Esperar a que el usuario presione Enter
        System.out.print(LIMPIAR_PANTALLA); // Limpiar la pantalla
        System.out.flush();
    }

    public static String cargarConfiguracion(String configFileName) {
        File f = new File(configFileName);
        if (!f.exists())
            return null;

        Properties properties = new Properties();
        try (FileInputStream fis = new FileInputStream(configFileName)) {
            properties.load(fis);
            return properties.getProperty("dataFileName");
        } catch (IOException e) {
            System.out.println(ROJO + "Error al cargar la configuración: " + e.getMessage() + RESET);
            return null;
        }
    }
}

class Empleado5 implements Serializable {
    private int id;
    private String nombre, apellidos, departamento;
    private double sueldo;

    public Empleado5(int id, String nombre, String apellidos, String departamento, double sueldo) {
        this.id = id;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.departamento = departamento;
        this.sueldo = sueldo;
    }
    public Empleado5() { }
    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public String getApellidos() { return apellidos; }
    public String getDepartamento() { return departamento; }
    public double getSueldo() { return sueldo; }

    @Override
    public String toString() {
        String format = Utiles4.AZUL + "│" + Utiles4.VERDE + " %-10s " + Utiles4.AZUL + "│" + Utiles4.VERDE + " %-15s "
                + Utiles4.AZUL + "│" + Utiles4.VERDE + " %-20s " + Utiles4.AZUL + "│" + Utiles4.VERDE + " %-15s "
                + Utiles4.AZUL + "│" + Utiles4.VERDE + " %-15s " + Utiles4.AZUL + "│" + Utiles4.RESET;
        return String.format(format, id, nombre, apellidos, departamento, sueldo);
    }

    public static void mostrarCabeceraListado(String texto) {
        System.out.println(Utiles4.AZUL + texto);
        System.out.println("┌────────────┬─────────────────┬──────────────────────┬─────────────────┬─────────────────┐");
        System.out.println("│ ID         │ Nombre          │ Apellidos            │ Departamento    │ Sueldo          │");
        System.out.println("├────────────┼─────────────────┼──────────────────────┼─────────────────┼─────────────────┤");
        System.out.print(Utiles4.RESET);
    }

    public static void mostrarFinalListado() {
        System.out.println(Utiles4.AZUL + "└────────────┴─────────────────┴──────────────────────┴─────────────────┴─────────────────┘" + Utiles4.RESET);
    }
}

class EmpleadosDAO4 {
    private List<Empleado5> empleados;
    private String archivo;

    public EmpleadosDAO4(String configFileName) {
        archivo = Utiles4.cargarConfiguracion(configFileName);
        if (archivo == null)
            archivo = "empleados.json";
        empleados = new ArrayList<>();
        File f = new File(archivo);
        if (!f.exists()) {
            try (RandomAccessFile raf = new RandomAccessFile(archivo, "rw")) {
                raf.writeInt(0);
            } catch (IOException e) {
                System.out.println("Error al crear el archivo: " + e.getMessage());
            }
        } else
            cargarEmpleadosDesdeArchivo();
    }

    public void crearEmpleado(Empleado5 empleado) {
        empleados.add(empleado);
        guardarEmpleadosEnArchivo();
    }

    public List<Empleado5> leerEmpleados() {
        return new ArrayList<>(empleados);
    }

    public Empleado5 leerEmpleadoPorID(int id) {
        return empleados.stream()
                .filter(empleado -> empleado.getId() == id)
                .findFirst()
                .orElse(null);
    }

    public void actualizarEmpleado(Empleado5 empleadoActualizado) {
        for (int i = 0; i < empleados.size(); i++) {
            if (empleados.get(i).getId() == empleadoActualizado.getId()) {
                empleados.set(i, empleadoActualizado);
                guardarEmpleadosEnArchivo();
                return;
            }
        }
    }

    public void eliminarEmpleado(int id) {
        empleados.removeIf(empleado -> empleado.getId() == id);
        guardarEmpleadosEnArchivo();
    }

    private void cargarEmpleadosDesdeArchivo() {
        ObjectMapper objectMapper = new ObjectMapper(); // Crear un objeto ObjectMapper

        try { // Deserializar la lista de empleados desde el archivo JSON
            empleados = objectMapper.readValue(new File(archivo), new TypeReference<>() { });
        } catch (IOException e) {
            System.out.println(Utiles.ROJO + "Error: " + e.getMessage() + Utiles.RESET);
        }
    }

    private void guardarEmpleadosEnArchivo() {
        ObjectMapper objectMapper = new ObjectMapper(); // Crear un objeto ObjectMapper

        try { // Serializar la lista de empleados a un archivo JSON
            objectMapper.writeValue(new File(archivo), empleados);
        } catch (IOException e) {
            System.out.println(Utiles.ROJO + "Error: " + e.getMessage() + Utiles.RESET);
        }
    }
}

public class GestionEmpleados4 {
    public static void main(String[] args) {
        EmpleadosDAO4 dao = new EmpleadosDAO4("config.properties");
        int opcion;
        boolean primerIngreso = true;

        do {
            if (!primerIngreso)
                Utiles4.pulseIntroParaContinuar();
            else {
                System.out.print(Utiles4.LIMPIAR_PANTALLA);
                System.out.flush();
                primerIngreso = false;
            }

            mostrarMenu();
            opcion = Utiles4.leerEnteroValido("Seleccione una opción: ");

            switch (opcion) {
                case 1 -> crearEmpleado(dao);
                case 2 -> leerTodosLosEmpleados(dao);
                case 3 -> leerEmpleadoPorID(dao);
                case 4 -> actualizarEmpleado(dao);
                case 5 -> eliminarEmpleado(dao);
                case 0 -> System.out.println(Utiles4.AZUL + "Saliendo del programa." + Utiles4.RESET);
                default -> System.out.println(Utiles4.ROJO + "Opción no válida. Intente de nuevo." + Utiles4.RESET);
            }
        } while (opcion != 0);
    }

    private static void mostrarMenu() {
        System.out.println(Utiles4.MORADO);
        System.out.println("┌──────── Menú de Empleados ────────┐");
        System.out.println("│ 1.- Crear empleado.               │");
        System.out.println("│ 2.- Mostrar todos los empleados.  │");
        System.out.println("│ 3.- Buscar empleado por ID.       │");
        System.out.println("│ 4.- Actualizar empleado.          │");
        System.out.println("│ 5.- Borrar empleado.              │");
        System.out.println("│ 0.- Salir.                        │");
        System.out.println("└───────────────────────────────────┘");
        System.out.print(Utiles4.RESET);
    }

    private static void crearEmpleado(EmpleadosDAO4 dao) {
        int id = Utiles4.leerEnteroValido("Ingresa ID: ");
        String nombre = Utiles4.leerTextoConLongitudMaxima("Ingresa nombre: ", 15);
        String apellidos = Utiles4.leerTextoConLongitudMaxima("Ingresa apellidos: ", 20);
        String departamento = Utiles4.leerTextoConLongitudMaxima("Ingresa departamento: ", 15);
        double sueldo = Utiles4.leerDoubleValido("Ingresa sueldo: ");

        Empleado5 empleado = new Empleado5(id, nombre, apellidos, departamento, sueldo);
        dao.crearEmpleado(empleado);
        System.out.println(Utiles4.VERDE + "Empleado creado con éxito." + Utiles4.RESET);
    }

    private static void leerTodosLosEmpleados(EmpleadosDAO4 dao) {
        List<Empleado5> empleados = dao.leerEmpleados();

        if (empleados.isEmpty())
            System.out.println(Utiles4.ROJO + "No hay empleados registrados." + Utiles4.RESET);
        else {
            Empleado5.mostrarCabeceraListado("Lista de Empleados:");
            empleados.forEach(System.out::println);
            Empleado5.mostrarFinalListado();
        }
    }

    private static void leerEmpleadoPorID(EmpleadosDAO4 dao) {
        int id = Utiles4.leerEnteroValido("Ingresa ID del empleado a buscar: ");
        Empleado5 empleado = dao.leerEmpleadoPorID(id);

        if (empleado != null) {
            Empleado5.mostrarCabeceraListado("Empleado encontrado:");
            System.out.println(empleado);
            Empleado5.mostrarFinalListado();
        } else
            System.out.println(Utiles4.ROJO + "Empleado no encontrado." + Utiles4.RESET);
    }

    private static void actualizarEmpleado(EmpleadosDAO4 dao) {
        int id = Utiles4.leerEnteroValido("Ingresa ID del empleado a actualizar: ");
        Empleado5 empleadoExistente = dao.leerEmpleadoPorID(id);

        if (empleadoExistente != null) {
            Empleado5.mostrarCabeceraListado("Empleado actual:");
            System.out.println(empleadoExistente);
            Empleado5.mostrarFinalListado();

            String nuevoNombre = Utiles4.leerTextoConLongitudMaxima("Ingresa el nuevo nombre: ", 15);
            String nuevosApellidos = Utiles4.leerTextoConLongitudMaxima("Ingresa los nuevos apellidos: ", 20);
            String nuevoDepartamento = Utiles4.leerTextoConLongitudMaxima("Ingresa el nuevo departamento: ", 15);
            double nuevoSueldo = Utiles4.leerDoubleValido("Ingresa nuevo Sueldo: ");

            Empleado5 empleadoActualizado = new Empleado5(id, nuevoNombre, nuevosApellidos, nuevoDepartamento, nuevoSueldo);
            dao.actualizarEmpleado(empleadoActualizado);
            System.out.println(Utiles4.VERDE + "Empleado actualizado con éxito." + Utiles4.RESET);
        } else
            System.out.println(Utiles4.ROJO + "Empleado no encontrado." + Utiles4.RESET);
    }

    private static void eliminarEmpleado(EmpleadosDAO4 dao) {
        int id = Utiles4.leerEnteroValido("Ingresa el ID del empleado a eliminar: ");
        Empleado5 empleadoExistente = dao.leerEmpleadoPorID(id);

        if (empleadoExistente != null) {
            dao.eliminarEmpleado(id);
            System.out.println(Utiles4.VERDE + "Empleado eliminado con éxito." + Utiles4.RESET);
        } else
            System.out.println(Utiles4.ROJO + "Empleado no encontrado." + Utiles4.RESET);
    }
}
