package U1;

import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;

public class EjemploDataInputStream {
    public static void main(String[] args) {
        try (DataInputStream di = new DataInputStream(new FileInputStream("datos.bin"))) {
            boolean valorBooleano = di.readBoolean(); // Leer y mostrar un valor booleano
            System.out.println("Valor booleano: " + valorBooleano);

            int valorEntero = di.readInt(); // Leer y mostrar un valor entero
            System.out.println("Valor entero: " + valorEntero);

            float valorFlotante = di.readFloat(); // Leer y mostrar un valor de punto flotante
            System.out.println("Valor de punto flotante: " + valorFlotante);

            String cadenaTexto = di.readUTF(); // Leer y mostrar una cadena de texto (UTF-8)
            System.out.println("Cadena de texto: " + cadenaTexto);
        } catch (IOException e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
        }
    }
}
