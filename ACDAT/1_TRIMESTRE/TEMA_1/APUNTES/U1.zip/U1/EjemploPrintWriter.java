package U1;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class EjemploPrintWriter {
    public static void main(String[] args) {
        String archivoSalida = "output.txt";

        // Uso de try-with-resources para manejo automático de recursos
        try (PrintWriter writer = new PrintWriter(new FileWriter(archivoSalida))) {
            // Escribir datos en el archivo
            writer.println("Ejemplo de uso de PrintWriter:");
            writer.println(); // Línea en blanco

            int numero = 42;
            double valorDoble = 3.14;
            boolean esVerdadero = true;
            String cadena = "Hola, mundo!";

            // Escribir diferentes tipos de datos en el archivo
            writer.println(numero);
            writer.println(valorDoble);
            writer.println(esVerdadero);
            writer.println(cadena);

            System.out.println("Datos escritos en el archivo " + archivoSalida);
        } catch (IOException e) {
            System.err.println("Error al escribir en el archivo: " + e.getMessage());
        }
    }
}
