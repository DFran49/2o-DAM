package U1;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class LecturaDePersonas {
    public static void main(String[] args) {
        // Deserialización de objetos Persona
        try (FileInputStream fileIn = new FileInputStream("personas.obj");
             ObjectInputStream objectIn = new ObjectInputStream(fileIn)) {
            // Leer los objetos desde el archivo
            Persona persona1 = (Persona) objectIn.readObject();
            Persona persona2 = (Persona) objectIn.readObject();

            // Mostrar los objetos leídos
            System.out.println(persona1);
            System.out.println(persona2);
        } catch (IOException e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
        } catch (ClassNotFoundException e) {
            System.out.println("Clase no encontrada al deserializar un objeto: " + e.getMessage());
        }
    }
}
