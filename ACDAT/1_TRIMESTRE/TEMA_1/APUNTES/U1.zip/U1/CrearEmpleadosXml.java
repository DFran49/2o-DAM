package U1;

import org.w3c.dom.*;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.io.RandomAccessFile;

public class CrearEmpleadosXml {
    public static void main(String[] args) {
        File inputFile = new File("empleados.dat");
        File outputFile = new File("empleados.xml");

        try (RandomAccessFile raf = new RandomAccessFile(inputFile, "r")) {
            // Crear DocumentBuilderFactory y DocumentBuilder
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.newDocument();  // Crear un nuevo documento XML

            // Crear el nodo raíz "empleados"
            Element rootElement = document.createElement("empleados");
            document.appendChild(rootElement);

            // Leer número de empleados
            int numEmpleados = raf.readInt();
            for (int i = 0; i < numEmpleados; i++) {
                int id = raf.readInt();
                String nombre = raf.readUTF();
                String apellidos = raf.readUTF();
                String departamento = raf.readUTF();
                double sueldo = raf.readDouble();

                if (id > 0) {
                    Element empleado = document.createElement("empleado");
                    rootElement.appendChild(empleado);

                    crearElemento("id", Integer.toString(id), empleado, document);
                    crearElemento("nombre", nombre.trim(), empleado, document);
                    crearElemento("apellidos", apellidos.trim(), empleado, document);
                    crearElemento("departamento", departamento.trim(), empleado, document);
                    crearElemento("sueldo", Double.toString(sueldo), empleado, document);
                }
            }

            // Convertir el documento a archivo XML
            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            Source source = new DOMSource(document);
            Result result = new StreamResult(outputFile);
            transformer.transform(source, result);

            System.out.println("Archivo XML creado con éxito.");
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
        }
    }

    private static void crearElemento(String nombre, String valor, Element raiz, Document document) {
        Element elemento = document.createElement(nombre);
        elemento.appendChild(document.createTextNode(valor));
        raiz.appendChild(elemento);
    }
}
