package U1;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JSONEjemplo1 {
    public static void main(String[] args) {
        ObjectMapper objectMapper = new ObjectMapper();
        String jsonString = "{\"nombre\": \"Juan\", \"edad\": 25}";

        try {
            Persona2 persona = objectMapper.readValue(jsonString, Persona2.class);
            System.out.println("Nombre: " + persona.getNombre());
            System.out.println("Edad: " + persona.getEdad());
        } catch (JsonProcessingException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}

class Persona2 {
    @JsonProperty("nombre")
    private String nombre;
    @JsonProperty("edad")
    private int edad;

    public String getNombre() {
        return nombre;
    }

    public int getEdad() {
        return edad;
    }
}
