package U1;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class CopiarImagenEjemplo {
    public static void main(String[] args) {
        String srcFile = "foto.jpg";
        String destFile1 = "foto1.jpg";
        String destFile2 = "foto2.jpg";

        try (BufferedInputStream bis = new BufferedInputStream(new FileInputStream(srcFile));
             BufferedOutputStream bos1 = new BufferedOutputStream(new FileOutputStream(destFile1));
             BufferedOutputStream bos2 = new BufferedOutputStream(new FileOutputStream(destFile2))) {
            // Usando readAllBytes para copiar la imagen a foto1.jpg
            byte[] imageBytes = bis.readAllBytes();
            bos1.write(imageBytes);
            System.out.println("La imagen ha sido copiada usando readAllBytes.");

            // Volver al inicio del flujo para la segunda operación
            bis.close(); // Cerrar el primer flujo
            // Reabrir el flujo para la segunda operación
            try (BufferedInputStream bis2 = new BufferedInputStream(new FileInputStream(srcFile))) {
                bis2.transferTo(bos2);
            }
            System.out.println("La imagen ha sido copiada usando transferTo.");
        } catch (IOException e) {
            System.err.println("Ocurrió un error durante la copia de la imagen: " + e.getMessage());
        }
    }
}
