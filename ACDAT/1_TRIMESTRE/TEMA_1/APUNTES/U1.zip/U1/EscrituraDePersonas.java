package U1;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class EscrituraDePersonas {
    public static void main(String[] args) {
        // Serialización de objetos Persona
        try (FileOutputStream fileOut = new FileOutputStream("personas.obj");
             ObjectOutputStream objectOut = new ObjectOutputStream(fileOut)) {
            // Crear y escribir los objetos en el archivo
            objectOut.writeObject(new Persona("Juan", 18));
            objectOut.writeObject(new Persona("Carlos", 22));

            System.out.println("Objetos escritos en el archivo.");
        } catch (IOException e) {
            System.out.println("Error al escribir en el archivo: " + e.getMessage());
        }
    }
}
