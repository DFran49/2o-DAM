package U1;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class SerializacionClientes {
    private static final String FILE_NAME = "cliente.obj"; // Nombre del archivo

    public static void main(String[] args) {
        Cliente cliente = new Cliente("Juan Moreno", "Dam1234.!");

        // Serialización
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(FILE_NAME))) {
            salida.writeObject("Datos del cliente\n");
            salida.writeObject(cliente);
        } catch (IOException e) {
            System.out.println("Error durante la serialización: " + e.getMessage());
        }

        // Deserialización
        try (ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(FILE_NAME))) {
            String mensaje = (String) entrada.readObject();
            Cliente clienteLeido = (Cliente) entrada.readObject();
            System.out.println("--------------------------------");
            System.out.println(mensaje + " " + clienteLeido);
            System.out.println("--------------------------------");
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error durante la deserialización: " + e.getMessage());
        }
    }
}
