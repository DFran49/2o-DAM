package U1;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class EscribirFicheroConFormato2 {
    public static void main(String[] args) {
        String archivoSalida = "salida.txt";
        String nombre = "Juan Moreno";
        int edad = 30;
        double altura = 1.75;

        // Manejo de recursos con try-with-resources
        try (PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(archivoSalida)))) {
            pw.printf("Nombre: %s%n", nombre);
            pw.printf("Edad: %d%n", edad);
            pw.printf("Altura: %.2f%n", altura);
            pw.printf("Altura en notación científica: %.2e%n", altura);
            pw.printf("Altura en notación científica con letras mayúsculas: %.2E%n", altura);
            pw.printf("Edad en hexadecimal: %x%n", edad); // Cambiado "Altura" a "Edad"
            pw.printf("Edad en octal: %o%n", edad);       // Cambiado "Altura" a "Edad"
            pw.printf("¿Es mayor de edad? %b%n", edad >= 18);
            pw.printf("Carácter: %c%n", 'A');
            pw.printf("Cadena con ancho de campo de 20 caracteres: %20s%n", nombre);
            pw.printf("Cadena alineada a la izquierda con ancho de campo de 20 caracteres: %-20s%n", nombre);
            pw.printf("Entero con ancho de campo de 5 caracteres: %5d%n", edad);
            pw.printf("Entero rellenado con ceros con ancho de campo de 5 caracteres: %05d%n", edad);

            System.out.println("Archivo de salida creado con éxito.");
        } catch (IOException e) {
            System.err.println("Error al escribir en el archivo: " + e.getMessage());
        }
    }
}
