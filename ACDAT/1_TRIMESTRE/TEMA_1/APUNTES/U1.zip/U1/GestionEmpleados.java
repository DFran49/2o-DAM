package U1;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;

class Utiles {
    public static final String ROJO = "\033[31m";
    public static final String VERDE = "\033[32m";
    public static final String AZUL = "\033[34m";
    public static final String MORADO = "\033[35m";
    public static final String RESET = "\033[0m";
    public static final String LIMPIAR_PANTALLA = "\033[2J";

    private static final Scanner SCANNER = new Scanner(System.in);

    public static int leerEnteroValido(String texto) {
        int numero;
        while (true) {
            System.out.print(texto);
            if (SCANNER.hasNextInt()) {
                numero = SCANNER.nextInt();
                SCANNER.nextLine(); // Consumir la nueva línea
                return numero;
            } else {
                System.out.println("Valor no válido. Por favor, ingresa un número entero.");
                SCANNER.nextLine(); // Limpiar el búfer de entrada
            }
        }
    }

    public static double leerDoubleValido(String mensaje) {
        double numero;
        while (true) {
            System.out.print(mensaje);
            if (SCANNER.hasNextDouble()) {
                numero = SCANNER.nextDouble();
                SCANNER.nextLine(); // Consumir la nueva línea
                return numero;
            } else {
                System.out.println("Valor no válido. Por favor, ingresa un número decimal.");
                SCANNER.nextLine(); // Limpiar el búfer de entrada
            }
        }
    }

    public static String leerTextoConLongitudMaxima(String mensaje, int longitudMaxima) {
        String texto;
        while (true) {
            System.out.print(mensaje);
            texto = SCANNER.nextLine();
            if (texto.isEmpty())
                System.out.println("El texto no puede dejarse vacío. Intenta de nuevo.");
            else if (texto.length() > longitudMaxima)
                System.out.println("El texto tiene más de " + longitudMaxima + " caracteres. Intenta de nuevo.");
            else
                return texto;
        }
    }

    public static void pulseIntroParaContinuar() {
        System.out.println("Presione INTRO para continuar...");
        SCANNER.nextLine(); // Esperar a que el usuario presione Enter
        System.out.print(LIMPIAR_PANTALLA); // Limpiar la pantalla
        System.out.flush();
    }

    public static String cargarConfiguracion(String configFileName) {
        File f = new File(configFileName);
        if (!f.exists())
            return null;

        Properties properties = new Properties();
        try (FileInputStream fis = new FileInputStream(configFileName)) {
            properties.load(fis);
            return properties.getProperty("dataFileName");
        } catch (IOException e) {
            System.out.println(ROJO + "Error al cargar la configuración: " + e.getMessage() + RESET);
            return null;
        }
    }
}

class Empleado implements Serializable {
    private int id;
    private String nombre, apellidos, departamento;
    private double sueldo;

    public Empleado(int id, String nombre, String apellidos, String departamento, double sueldo) {
        this.id = id;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.departamento = departamento;
        this.sueldo = sueldo;
    }

    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public String getApellidos() { return apellidos; }
    public String getDepartamento() { return departamento; }
    public double getSueldo() { return sueldo; }

    @Override
    public String toString() {
        String format = Utiles.AZUL + "│" + Utiles.VERDE + " %-10s " + Utiles.AZUL + "│" + Utiles.VERDE + " %-15s "
                + Utiles.AZUL + "│" + Utiles.VERDE + " %-20s " + Utiles.AZUL + "│" + Utiles.VERDE + " %-15s "
                + Utiles.AZUL + "│" + Utiles.VERDE + " %-15s " + Utiles.AZUL + "│" + Utiles.RESET;
        return String.format(format, id, nombre, apellidos, departamento, sueldo);
    }

    public static void mostrarCabeceraListado(String texto) {
        System.out.println(Utiles.AZUL + texto);
        System.out.println("┌────────────┬─────────────────┬──────────────────────┬─────────────────┬─────────────────┐");
        System.out.println("│ ID         │ Nombre          │ Apellidos            │ Departamento    │ Sueldo          │");
        System.out.println("├────────────┼─────────────────┼──────────────────────┼─────────────────┼─────────────────┤");
        System.out.print(Utiles.RESET);
    }

    public static void mostrarFinalListado() {
        System.out.println(Utiles.AZUL + "└────────────┴─────────────────┴──────────────────────┴─────────────────┴─────────────────┘" + Utiles.RESET);
    }
}

class EmpleadosDAO {
    private List<Empleado> empleados;
    private String archivo;

    public EmpleadosDAO(String configFileName) {
        archivo = Utiles.cargarConfiguracion(configFileName);
        if (archivo == null)
            archivo = "empleados.dat";
        empleados = new ArrayList<>();
        File f = new File(archivo);
        if (!f.exists()) {
            try (RandomAccessFile raf = new RandomAccessFile(archivo, "rw")) {
                raf.writeInt(0);
            } catch (IOException e) {
                System.out.println("Error al crear el archivo: " + e.getMessage());
            }
        } else
            cargarEmpleadosDesdeArchivo();
    }

    public void crearEmpleado(Empleado empleado) {
        empleados.add(empleado);
        guardarEmpleadosEnArchivo();
    }

    public List<Empleado> leerEmpleados() {
        return new ArrayList<>(empleados);
    }

    public Empleado leerEmpleadoPorID(int id) {
        return empleados.stream()
                .filter(empleado -> empleado.getId() == id)
                .findFirst()
                .orElse(null);
    }

    public void actualizarEmpleado(Empleado empleadoActualizado) {
        for (int i = 0; i < empleados.size(); i++) {
            if (empleados.get(i).getId() == empleadoActualizado.getId()) {
                empleados.set(i, empleadoActualizado);
                guardarEmpleadosEnArchivo();
                return;
            }
        }
    }

    public void eliminarEmpleado(int id) {
        empleados.removeIf(empleado -> empleado.getId() == id);
        guardarEmpleadosEnArchivo();
    }

    private void cargarEmpleadosDesdeArchivo() {
        try (RandomAccessFile raf = new RandomAccessFile(archivo, "r")) {
            int numEmpleados = raf.readInt();
            for (int i = 0; i < numEmpleados; i++) {
                int id = raf.readInt();
                String nombre = raf.readUTF();
                String apellidos = raf.readUTF();
                String departamento = raf.readUTF();
                double sueldo = raf.readDouble();
                empleados.add(new Empleado(id, nombre, apellidos, departamento, sueldo));
            }
        } catch (IOException e) {
            System.out.println(Utiles.ROJO + "Error al cargar empleados: " + e.getMessage() + Utiles.RESET);
        }
    }

    private void guardarEmpleadosEnArchivo() {
        File archivoFile = new File(archivo);

        if (archivoFile.exists())
            archivoFile.delete();

        try (RandomAccessFile raf = new RandomAccessFile(archivo, "rw")) {
            raf.writeInt(empleados.size());
            for (Empleado empleado : empleados) {
                raf.writeInt(empleado.getId());
                raf.writeUTF(empleado.getNombre());
                raf.writeUTF(empleado.getApellidos());
                raf.writeUTF(empleado.getDepartamento());
                raf.writeDouble(empleado.getSueldo());
            }
        } catch (IOException e) {
            System.out.println(Utiles.ROJO + "Error al guardar empleados: " + e.getMessage() + Utiles.RESET);
        }
    }
}

public class GestionEmpleados {
    public static void main(String[] args) {
        EmpleadosDAO dao = new EmpleadosDAO("config.properties");
        int opcion;
        boolean primerIngreso = true;

        do {
            if (!primerIngreso)
                Utiles.pulseIntroParaContinuar();
            else {
                System.out.print(Utiles.LIMPIAR_PANTALLA);
                System.out.flush();
                primerIngreso = false;
            }

            mostrarMenu();
            opcion = Utiles.leerEnteroValido("Seleccione una opción: ");

            switch (opcion) {
                case 1 -> crearEmpleado(dao);
                case 2 -> leerTodosLosEmpleados(dao);
                case 3 -> leerEmpleadoPorID(dao);
                case 4 -> actualizarEmpleado(dao);
                case 5 -> eliminarEmpleado(dao);
                case 0 -> System.out.println(Utiles.AZUL + "Saliendo del programa." + Utiles.RESET);
                default -> System.out.println(Utiles.ROJO + "Opción no válida. Intente de nuevo." + Utiles.RESET);
            }
        } while (opcion != 0);
    }

    private static void mostrarMenu() {
        System.out.println(Utiles.MORADO);
        System.out.println("┌──────── Menú de Empleados ────────┐");
        System.out.println("│ 1.- Crear empleado.               │");
        System.out.println("│ 2.- Mostrar todos los empleados.  │");
        System.out.println("│ 3.- Buscar empleado por ID.       │");
        System.out.println("│ 4.- Actualizar empleado.          │");
        System.out.println("│ 5.- Borrar empleado.              │");
        System.out.println("│ 0.- Salir.                        │");
        System.out.println("└───────────────────────────────────┘");
        System.out.print(Utiles.RESET);
    }

    private static void crearEmpleado(EmpleadosDAO dao) {
        int id = Utiles.leerEnteroValido("Ingresa ID: ");
        String nombre = Utiles.leerTextoConLongitudMaxima("Ingresa nombre: ", 15);
        String apellidos = Utiles.leerTextoConLongitudMaxima("Ingresa apellidos: ", 20);
        String departamento = Utiles.leerTextoConLongitudMaxima("Ingresa departamento: ", 15);
        double sueldo = Utiles.leerDoubleValido("Ingresa sueldo: ");

        Empleado empleado = new Empleado(id, nombre, apellidos, departamento, sueldo);
        dao.crearEmpleado(empleado);
        System.out.println(Utiles.VERDE + "Empleado creado con éxito." + Utiles.RESET);
    }

    private static void leerTodosLosEmpleados(EmpleadosDAO dao) {
        List<Empleado> empleados = dao.leerEmpleados();

        if (empleados.isEmpty())
            System.out.println(Utiles.ROJO + "No hay empleados registrados." + Utiles.RESET);
        else {
            Empleado.mostrarCabeceraListado("Lista de Empleados:");
            empleados.forEach(System.out::println);
            Empleado.mostrarFinalListado();
        }
    }

    private static void leerEmpleadoPorID(EmpleadosDAO dao) {
        int id = Utiles.leerEnteroValido("Ingresa ID del empleado a buscar: ");
        Empleado empleado = dao.leerEmpleadoPorID(id);

        if (empleado != null) {
            Empleado.mostrarCabeceraListado("Empleado encontrado:");
            System.out.println(empleado);
            Empleado.mostrarFinalListado();
        } else
            System.out.println(Utiles.ROJO + "Empleado no encontrado." + Utiles.RESET);
    }

    private static void actualizarEmpleado(EmpleadosDAO dao) {
        int id = Utiles.leerEnteroValido("Ingresa ID del empleado a actualizar: ");
        Empleado empleadoExistente = dao.leerEmpleadoPorID(id);

        if (empleadoExistente != null) {
            Empleado.mostrarCabeceraListado("Empleado actual:");
            System.out.println(empleadoExistente);
            Empleado.mostrarFinalListado();

            String nuevoNombre = Utiles.leerTextoConLongitudMaxima("Ingresa el nuevo nombre: ", 15);
            String nuevosApellidos = Utiles.leerTextoConLongitudMaxima("Ingresa los nuevos apellidos: ", 20);
            String nuevoDepartamento = Utiles.leerTextoConLongitudMaxima("Ingresa el nuevo departamento: ", 15);
            double nuevoSueldo = Utiles.leerDoubleValido("Ingresa nuevo Sueldo: ");

            Empleado empleadoActualizado = new Empleado(id, nuevoNombre, nuevosApellidos, nuevoDepartamento, nuevoSueldo);
            dao.actualizarEmpleado(empleadoActualizado);
            System.out.println(Utiles.VERDE + "Empleado actualizado con éxito." + Utiles.RESET);
        } else
            System.out.println(Utiles.ROJO + "Empleado no encontrado." + Utiles.RESET);
    }

    private static void eliminarEmpleado(EmpleadosDAO dao) {
        int id = Utiles.leerEnteroValido("Ingresa el ID del empleado a eliminar: ");
        Empleado empleadoExistente = dao.leerEmpleadoPorID(id);

        if (empleadoExistente != null) {
            dao.eliminarEmpleado(id);
            System.out.println(Utiles.VERDE + "Empleado eliminado con éxito." + Utiles.RESET);
        } else
            System.out.println(Utiles.ROJO + "Empleado no encontrado." + Utiles.RESET);
    }
}
