package U1;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class HerenciaSerializable {
    public static void main(String[] args) {
        Figura fig1 = new Rectangulo(10, 15, 30, 60);
        Figura fig2 = new Circulo(12, 19, 60);

        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream("figura.obj"));
             ObjectInputStream entrada = new ObjectInputStream(new FileInputStream("figura.obj"))) {
            salida.writeObject("Guardar un objeto de una clase hija\n");
            salida.writeObject(fig1);
            salida.writeObject(fig2);

            // Leer objetos del archivo
            String str = (String) entrada.readObject();
            Figura obj1 = (Figura) entrada.readObject();
            Figura obj2 = (Figura) entrada.readObject();

            System.out.println("----------------------------------------------");
            System.out.print(str);
            System.out.println(obj1.getClass().getSimpleName() + " origen ("
                    + obj1.x + "," + obj1.y + ")" + " – área = " + obj1.area());
            System.out.println(obj2.getClass().getSimpleName() + " origen ("
                    + obj2.x + "," + obj2.y + ")" + " – área = " + obj2.area());
            System.out.println("----------------------------------------------");
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
