package U1;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;

class Utiles2 {
    public static final String ROJO = "\033[31m";
    public static final String VERDE = "\033[32m";
    public static final String AZUL = "\033[34m";
    public static final String MORADO = "\033[35m";
    public static final String RESET = "\033[0m";
    public static final String LIMPIAR_PANTALLA = "\033[2J";

    private static final Scanner SCANNER = new Scanner(System.in);

    public static int leerEnteroValido(String texto) {
        int numero;
        while (true) {
            System.out.print(texto);
            if (SCANNER.hasNextInt()) {
                numero = SCANNER.nextInt();
                SCANNER.nextLine(); // Consumir la nueva línea
                return numero;
            } else {
                System.out.println("Valor no válido. Por favor, ingresa un número entero.");
                SCANNER.nextLine(); // Limpiar el búfer de entrada
            }
        }
    }

    public static double leerDoubleValido(String mensaje) {
        double numero;
        while (true) {
            System.out.print(mensaje);
            if (SCANNER.hasNextDouble()) {
                numero = SCANNER.nextDouble();
                SCANNER.nextLine(); // Consumir la nueva línea
                return numero;
            } else {
                System.out.println("Valor no válido. Por favor, ingresa un número decimal.");
                SCANNER.nextLine(); // Limpiar el búfer de entrada
            }
        }
    }

    public static String leerTextoConLongitudMaxima(String mensaje, int longitudMaxima) {
        String texto;
        while (true) {
            System.out.print(mensaje);
            texto = SCANNER.nextLine();
            if (texto.isEmpty())
                System.out.println("El texto no puede dejarse vacío. Intenta de nuevo.");
            else if (texto.length() > longitudMaxima)
                System.out.println("El texto tiene más de " + longitudMaxima + " caracteres. Intenta de nuevo.");
            else
                return texto;
        }
    }

    public static void pulseIntroParaContinuar() {
        System.out.println("Presione INTRO para continuar...");
        SCANNER.nextLine(); // Esperar a que el usuario presione Enter
        System.out.print(LIMPIAR_PANTALLA); // Limpiar la pantalla
        System.out.flush();
    }

    public static String cargarConfiguracion(String configFileName) {
        File f = new File(configFileName);
        if (!f.exists())
            return null;

        Properties properties = new Properties();
        try (FileInputStream fis = new FileInputStream(configFileName)) {
            properties.load(fis);
            return properties.getProperty("dataFileName");
        } catch (IOException e) {
            System.out.println(ROJO + "Error al cargar la configuración: " + e.getMessage() + RESET);
            return null;
        }
    }
}

class Empleado2 implements Serializable {
    private int id;
    private String nombre, apellidos, departamento;
    private double sueldo;

    public Empleado2(int id, String nombre, String apellidos, String departamento, double sueldo) {
        this.id = id;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.departamento = departamento;
        this.sueldo = sueldo;
    }

    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public String getApellidos() { return apellidos; }
    public String getDepartamento() { return departamento; }
    public double getSueldo() { return sueldo; }

    @Override
    public String toString() {
        String format = Utiles3.AZUL + "│" + Utiles3.VERDE + " %-10s " + Utiles3.AZUL + "│" + Utiles3.VERDE + " %-15s "
                + Utiles3.AZUL + "│" + Utiles3.VERDE + " %-20s " + Utiles3.AZUL + "│" + Utiles3.VERDE + " %-15s "
                + Utiles3.AZUL + "│" + Utiles3.VERDE + " %-15s " + Utiles3.AZUL + "│" + Utiles3.RESET;
        return String.format(format, id, nombre, apellidos, departamento, sueldo);
    }

    public static void mostrarCabeceraListado(String texto) {
        System.out.println(Utiles3.AZUL + texto);
        System.out.println("┌────────────┬─────────────────┬──────────────────────┬─────────────────┬─────────────────┐");
        System.out.println("│ ID         │ Nombre          │ Apellidos            │ Departamento    │ Sueldo          │");
        System.out.println("├────────────┼─────────────────┼──────────────────────┼─────────────────┼─────────────────┤");
        System.out.print(Utiles3.RESET);
    }

    public static void mostrarFinalListado() {
        System.out.println(Utiles3.AZUL + "└────────────┴─────────────────┴──────────────────────┴─────────────────┴─────────────────┘" + Utiles3.RESET);
    }
}

class EmpleadosDAO2 {
    private List<Empleado3> empleados;
    private String archivo;

    public EmpleadosDAO2(String configFileName) {
        archivo = Utiles3.cargarConfiguracion(configFileName);
        if (archivo == null)
            archivo = "empleados.dat";
        empleados = new ArrayList<>();
        File f = new File(archivo);
        if (!f.exists()) {
            try (RandomAccessFile raf = new RandomAccessFile(archivo, "rw")) {
                raf.writeInt(0);
            } catch (IOException e) {
                System.out.println("Error al crear el archivo: " + e.getMessage());
            }
        } else
            cargarEmpleadosDesdeArchivo();
    }

    public void crearEmpleado(Empleado3 empleado) {
        empleados.add(empleado);
        guardarEmpleadosEnArchivo();
    }

    public List<Empleado3> leerEmpleados() {
        return new ArrayList<>(empleados);
    }

    public Empleado3 leerEmpleadoPorID(int id) {
        return empleados.stream()
                .filter(empleado -> empleado.getId() == id)
                .findFirst()
                .orElse(null);
    }

    public void actualizarEmpleado(Empleado3 empleadoActualizado) {
        for (int i = 0; i < empleados.size(); i++) {
            if (empleados.get(i).getId() == empleadoActualizado.getId()) {
                empleados.set(i, empleadoActualizado);
                guardarEmpleadosEnArchivo();
                return;
            }
        }
    }

    public void eliminarEmpleado(int id) {
        empleados.removeIf(empleado -> empleado.getId() == id);
        guardarEmpleadosEnArchivo();
    }

    private void cargarEmpleadosDesdeArchivo() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(archivo))) {
            empleados = (List<Empleado3>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println(Utiles3.ROJO + "Error: " + e.getMessage() + Utiles3.RESET);
        }
    }

    private void guardarEmpleadosEnArchivo() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(archivo))) {
            oos.writeObject(empleados);
        } catch (IOException e) {
            System.out.println(Utiles3.ROJO + "Error: " + e.getMessage() + Utiles3.RESET);
        }
    }
}

public class GestionEmpleados2 {
    public static void main(String[] args) {
        EmpleadosDAO3 dao = new EmpleadosDAO3("config.properties");
        int opcion;
        boolean primerIngreso = true;

        do {
            if (!primerIngreso)
                Utiles3.pulseIntroParaContinuar();
            else {
                System.out.print(Utiles3.LIMPIAR_PANTALLA);
                System.out.flush();
                primerIngreso = false;
            }

            mostrarMenu();
            opcion = Utiles3.leerEnteroValido("Seleccione una opción: ");

            switch (opcion) {
                case 1 -> crearEmpleado(dao);
                case 2 -> leerTodosLosEmpleados(dao);
                case 3 -> leerEmpleadoPorID(dao);
                case 4 -> actualizarEmpleado(dao);
                case 5 -> eliminarEmpleado(dao);
                case 0 -> System.out.println(Utiles3.AZUL + "Saliendo del programa." + Utiles3.RESET);
                default -> System.out.println(Utiles3.ROJO + "Opción no válida. Intente de nuevo." + Utiles3.RESET);
            }
        } while (opcion != 0);
    }

    private static void mostrarMenu() {
        System.out.println(Utiles3.MORADO);
        System.out.println("┌──────── Menú de Empleados ────────┐");
        System.out.println("│ 1.- Crear empleado.               │");
        System.out.println("│ 2.- Mostrar todos los empleados.  │");
        System.out.println("│ 3.- Buscar empleado por ID.       │");
        System.out.println("│ 4.- Actualizar empleado.          │");
        System.out.println("│ 5.- Borrar empleado.              │");
        System.out.println("│ 0.- Salir.                        │");
        System.out.println("└───────────────────────────────────┘");
        System.out.print(Utiles3.RESET);
    }

    private static void crearEmpleado(EmpleadosDAO3 dao) {
        int id = Utiles3.leerEnteroValido("Ingresa ID: ");
        String nombre = Utiles3.leerTextoConLongitudMaxima("Ingresa nombre: ", 15);
        String apellidos = Utiles3.leerTextoConLongitudMaxima("Ingresa apellidos: ", 20);
        String departamento = Utiles3.leerTextoConLongitudMaxima("Ingresa departamento: ", 15);
        double sueldo = Utiles3.leerDoubleValido("Ingresa sueldo: ");

        Empleado3 empleado = new Empleado3(id, nombre, apellidos, departamento, sueldo);
        dao.crearEmpleado(empleado);
        System.out.println(Utiles3.VERDE + "Empleado creado con éxito." + Utiles3.RESET);
    }

    private static void leerTodosLosEmpleados(EmpleadosDAO3 dao) {
        List<Empleado3> empleados = dao.leerEmpleados();

        if (empleados.isEmpty())
            System.out.println(Utiles3.ROJO + "No hay empleados registrados." + Utiles3.RESET);
        else {
            Empleado3.mostrarCabeceraListado("Lista de Empleados:");
            empleados.forEach(System.out::println);
            Empleado3.mostrarFinalListado();
        }
    }

    private static void leerEmpleadoPorID(EmpleadosDAO3 dao) {
        int id = Utiles3.leerEnteroValido("Ingresa ID del empleado a buscar: ");
        Empleado3 empleado = dao.leerEmpleadoPorID(id);

        if (empleado != null) {
            Empleado3.mostrarCabeceraListado("Empleado encontrado:");
            System.out.println(empleado);
            Empleado3.mostrarFinalListado();
        } else
            System.out.println(Utiles3.ROJO + "Empleado no encontrado." + Utiles3.RESET);
    }

    private static void actualizarEmpleado(EmpleadosDAO3 dao) {
        int id = Utiles3.leerEnteroValido("Ingresa ID del empleado a actualizar: ");
        Empleado3 empleadoExistente = dao.leerEmpleadoPorID(id);

        if (empleadoExistente != null) {
            Empleado3.mostrarCabeceraListado("Empleado actual:");
            System.out.println(empleadoExistente);
            Empleado3.mostrarFinalListado();

            String nuevoNombre = Utiles3.leerTextoConLongitudMaxima("Ingresa el nuevo nombre: ", 15);
            String nuevosApellidos = Utiles3.leerTextoConLongitudMaxima("Ingresa los nuevos apellidos: ", 20);
            String nuevoDepartamento = Utiles3.leerTextoConLongitudMaxima("Ingresa el nuevo departamento: ", 15);
            double nuevoSueldo = Utiles3.leerDoubleValido("Ingresa nuevo Sueldo: ");

            Empleado3 empleadoActualizado = new Empleado3(id, nuevoNombre, nuevosApellidos, nuevoDepartamento, nuevoSueldo);
            dao.actualizarEmpleado(empleadoActualizado);
            System.out.println(Utiles3.VERDE + "Empleado actualizado con éxito." + Utiles3.RESET);
        } else
            System.out.println(Utiles3.ROJO + "Empleado no encontrado." + Utiles3.RESET);
    }

    private static void eliminarEmpleado(EmpleadosDAO3 dao) {
        int id = Utiles3.leerEnteroValido("Ingresa el ID del empleado a eliminar: ");
        Empleado3 empleadoExistente = dao.leerEmpleadoPorID(id);

        if (empleadoExistente != null) {
            dao.eliminarEmpleado(id);
            System.out.println(Utiles3.VERDE + "Empleado eliminado con éxito." + Utiles3.RESET);
        } else
            System.out.println(Utiles3.ROJO + "Empleado no encontrado." + Utiles3.RESET);
    }
}
