package U1;

import java.io.FileInputStream;
import java.io.IOException;

public class EjemploFileInputStream {
    public static void main(String[] args) {
        String archivo = "archivo.bin"; // Ruta y nombre del archivo binario a leer

        try (FileInputStream fileInput = new FileInputStream(archivo)) {
            // Lee bytes del archivo y muestra su valor
            System.out.println("Leyendo bytes del archivo:");
            int byteLeido;
            while ((byteLeido = fileInput.read()) != -1)
                System.out.print(byteLeido + " ");

            long bytesSaltados = fileInput.skip(5); // Salta 5 bytes
            System.out.println("\n\nSe han saltado " + bytesSaltados + " bytes.");

            // Lee y muestra los siguientes 10 bytes
            System.out.println("\nLeyendo los siguientes 10 bytes:");
            byte[] buffer = new byte[10];
            int bytesRead = fileInput.read(buffer);
            for (int i = 0; i < bytesRead; i++)
                System.out.print(buffer[i] + " ");
        } catch (IOException e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
        }
    }
}
