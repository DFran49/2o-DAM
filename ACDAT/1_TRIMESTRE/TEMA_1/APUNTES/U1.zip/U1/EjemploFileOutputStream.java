package U1;

import java.io.FileOutputStream;
import java.io.IOException;

public class EjemploFileOutputStream {
    public static void main(String[] args) {
        String archivo = "archivo.bin"; // Ruta y nombre del archivo binario

        // Escribe bytes en el archivo utilizando FileOutputStream
        try (FileOutputStream fo = new FileOutputStream(archivo)) {
            // Escribe una secuencia de bytes en el archivo
            for (int i = 0; i < 100; i++)
                fo.write((byte) i); // Convierte el valor entero a byte y lo escribe

            fo.flush(); // Asegura que todos los datos pendientes se escriban en el archivo
            System.out.println("Datos escritos exitosamente en " + archivo);
        } catch (IOException e) { // Maneja errores de entrada/salida
            System.err.println("Error al escribir en el archivo: " + e.getMessage());
        }
    }
}
