package U1;

import java.io.File;

public class ListarArchivosEjemplo {
    public static void main(String[] args) {
        // Obtener el directorio actual
        String directorioActual = System.getProperty("user.dir");
        System.out.println("Directorio actual: " + directorioActual);

        // Crear una instancia de File para el directorio actual
        File directorio = new File(directorioActual);

        // Verificar si el objeto File representa un directorio
        if (directorio.isDirectory()) {
            // Obtener la lista de archivos y directorios en el directorio actual
            String[] listaArchivos = directorio.list();

            // Mostrar la lista de archivos y directorios
            if (listaArchivos != null && listaArchivos.length > 0) {
                System.out.println("Archivos y directorios en el directorio actual:");
                for (String archivo : listaArchivos)
                    System.out.println("  " + archivo);
            } else
                System.out.println("El directorio está vacío.");
        } else
            System.out.println("El path especificado no es un directorio válido.");
    }
}
