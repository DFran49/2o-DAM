package U1;

import java.io.EOFException;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

public class EjemploAccesoAleatorio {
    public static void main(String[] args) {
        try (RandomAccessFile archivo = new RandomAccessFile("archivo.txt", "rw")) {
            System.out.println("El tamaño del archivo es: " + archivo.length());

            byte b;
            while (true) {
                try {
                    b = archivo.readByte();
                    if (b == 'b') {
                        archivo.seek(archivo.getFilePointer() - 1);
                        archivo.writeByte('B');
                    }
                } catch (EOFException e) {
                    System.out.println("Todas las 'b' han sido convertidas a mayúsculas.");
                    break;
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("El archivo no existe.");
        } catch (IOException e) {
            System.out.println("Se produjo un error con el archivo: " + e.getMessage());
        }
    }
}
