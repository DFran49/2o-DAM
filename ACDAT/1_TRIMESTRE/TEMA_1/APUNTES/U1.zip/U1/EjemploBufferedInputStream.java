package U1;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;

public class EjemploBufferedInputStream {
    public static void main(String[] args) {
        String nombreArchivo = "datos.bin";

        try (BufferedInputStream bis = new BufferedInputStream(new FileInputStream(nombreArchivo))) {
            // Leer y mostrar un entero (4 bytes)
            int entero = bytesToInt(bis.readNBytes(4));
            System.out.println("Entero leído: " + entero);

            // Leer y mostrar un número decimal (float, 4 bytes)
            float decimalFloat = bytesToFloat(bis.readNBytes(4));
            System.out.println("Decimal (float) leído: " + decimalFloat);

            // Leer y mostrar un número decimal (double, 8 bytes)
            double decimalDouble = bytesToDouble(bis.readNBytes(8));
            System.out.println("Decimal (double) leído: " + decimalDouble);

            // Leer y mostrar una cadena de texto (resto del archivo)
            byte[] textoBytes = bis.readAllBytes();
            String texto = new String(textoBytes);
            System.out.println("Texto leído: " + texto);
        } catch (IOException e) {
            System.err.println("Error al leer el archivo: " + e.getMessage());
        }
    }

    // Método para convertir 4 bytes a un entero (Big Endian)
    private static int bytesToInt(byte[] bytes) {
        return ((bytes[0] & 0xFF) << 24) |
                ((bytes[1] & 0xFF) << 16) |
                ((bytes[2] & 0xFF) << 8) |
                (bytes[3] & 0xFF);
    }

    // Método para convertir 4 bytes a un float (Big Endian)
    private static float bytesToFloat(byte[] bytes) {
        int intBits = bytesToInt(bytes);
        return Float.intBitsToFloat(intBits);
    }

    // Método para convertir 8 bytes a un double (Big Endian)
    private static double bytesToDouble(byte[] bytes) {
        long longBits = ((long) (bytes[0] & 0xFF) << 56) |
                ((long) (bytes[1] & 0xFF) << 48) |
                ((long) (bytes[2] & 0xFF) << 40) |
                ((long) (bytes[3] & 0xFF) << 32) |
                ((long) (bytes[4] & 0xFF) << 24) |
                ((long) (bytes[5] & 0xFF) << 16) |
                ((long) (bytes[6] & 0xFF) << 8) |
                (bytes[7] & 0xFF);
        return Double.longBitsToDouble(longBits);
    }
}
