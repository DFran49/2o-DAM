package U1;

import java.io.IOException;
import java.io.RandomAccessFile;

public class ModificarDatosEnArchivo {
    public static void main(String[] args) {
        String archivo = "archivo.dat";

        try (RandomAccessFile raFile = new RandomAccessFile(archivo, "rw")) {
            // Escribir datos iniciales
            raFile.writeBoolean(true);
            raFile.writeInt(42);
            raFile.writeDouble(3.14159);

            // Leer y mostrar datos iniciales
            raFile.seek(0); // Volver al inicio del archivo
            boolean valorBooleano = raFile.readBoolean();
            int valorEntero = raFile.readInt();
            double valorDouble = raFile.readDouble();

            System.out.println("Datos iniciales:");
            System.out.println("Valor booleano: " + valorBooleano);
            System.out.println("Valor entero: " + valorEntero);
            System.out.println("Valor double: " + valorDouble);

            // Modificar el valor entero
            raFile.seek(1); // Mover al inicio del valor entero (booleano ocupa 1 byte)
            raFile.writeInt(100); // Modificar el valor entero

            // Agregar texto al final del archivo
            raFile.seek(raFile.length()); // Mover al final del archivo
            String nuevoTexto = "Texto agregado";
            raFile.writeUTF(nuevoTexto);

            // Leer y mostrar datos actualizados
            raFile.seek(0); // Volver al inicio del archivo
            valorBooleano = raFile.readBoolean();
            valorEntero = raFile.readInt(); // Leer el valor entero modificado
            valorDouble = raFile.readDouble();
            String textoAgregado = raFile.readUTF(); // Leer el texto agregado

            System.out.println("\nDatos después de modificar el entero y agregar texto:");
            System.out.println("Valor booleano: " + valorBooleano);
            System.out.println("Valor entero actualizado: " + valorEntero);
            System.out.println("Valor double: " + valorDouble);
            System.out.println("Texto agregado: " + textoAgregado);
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
