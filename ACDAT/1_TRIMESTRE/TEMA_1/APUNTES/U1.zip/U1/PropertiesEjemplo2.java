package U1;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class PropertiesEjemplo2 {
    public static void main(String[] args) {
        Properties properties = new Properties(); // Crear un objeto de la clase Properties

        // Agregar propiedades
        properties.setProperty("url", "jdbc:mysql://localhost:3306/mydb");
        properties.setProperty("username", "myuser");
        properties.setProperty("password", "mypassword");

        // Guardar las propiedades en "config.properties"
        try (FileOutputStream fileOut = new FileOutputStream("config.properties")) {
            properties.store(fileOut, "Configuración de la BD");
            System.out.println("Propiedades guardadas en el archivo.");
        } catch (IOException e) {
            System.err.println("Error al guardar las propiedades: " + e.getMessage());
        }

        // Recuperar las propiedades del archivo
        try (FileInputStream fileIn = new FileInputStream("config.properties")) {
            properties.load(fileIn);
            // Mostrar propiedades recuperadas
            System.out.println("\nPropiedades recuperadas del archivo:");
            System.out.println("URL de la BD: " + properties.getProperty("url"));
            System.out.println("Nombre de usuario: " + properties.getProperty("username"));
            System.out.println("Contraseña: " + properties.getProperty("password"));
        } catch (IOException e) {
            System.err.println("Error al cargar las propiedades: " + e.getMessage());
        }
    }
}
