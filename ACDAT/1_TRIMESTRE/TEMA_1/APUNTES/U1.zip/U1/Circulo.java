package U1;

public class Circulo extends Figura {
    private static final double PI = 3.1416;
    protected double radio;

    public Circulo(int x, int y, double radio) {
        super(x, y);
        this.radio = radio;
    }

    @Override
    public double area() {
        return PI * radio * radio;
    }
}
