package U1;

import java.io.FileReader;
import java.io.IOException;
import java.io.FileNotFoundException;

public class LeerArchivoCaracterACaracter {
    public static void main(String[] args) {
        String filePath = "archivo.txt";

        // Bloque try-with-resources para asegurar el cierre automático del FileReader
        try (FileReader reader = new FileReader(filePath)) {
            int charCode;

            while ((charCode = reader.read()) != -1) // Lectura carácter a carácter hasta el final
                System.out.print((char) charCode); // Convertir y mostrar cada carácter
        } catch (FileNotFoundException e) {
            System.err.println("Error: el archivo no fue encontrado - " + e.getMessage());
        } catch (IOException e) {
            System.err.println("Error al leer el archivo: " + e.getMessage());
        }
    }
}

