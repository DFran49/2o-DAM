package U1;

import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class EjemploDataOutputStream {
    public static void main(String[] args) {
        String archivo = "datos.bin"; // Ruta y nombre del archivo binario

        try (FileOutputStream fos = new FileOutputStream(archivo);
             DataOutputStream dos = new DataOutputStream(fos)) {
            dos.writeBoolean(true); // Escribe un valor booleano
            dos.writeInt(42); // Escribe un entero
            dos.writeFloat(3.14f); // Escribe un valor de punto flotante
            dos.writeUTF("Hola, mundo!"); // Escribe una cadena en formato UTF-8

            dos.flush(); // Limpia el flujo de salida para asegurarse de que todos los datos se escriban

            System.out.println("Datos escritos en el archivo correctamente.");
        } catch (IOException e) {
            System.err.println("Error al escribir en el archivo: " + e.getMessage());
        }
    }
}
