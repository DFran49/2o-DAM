package U1;

import java.util.Properties;

public class PropertiesEjemplo {
    public static void main(String[] args) {
        Properties properties = new Properties(); // Crear un objeto Properties

        // Agregar propiedades
        properties.setProperty("nombre", "Juan");
        properties.setProperty("edad", "30");
        properties.setProperty("email", "juan@ejemplo.com");

        // Obtener y mostrar una propiedad
        String nombre = properties.getProperty("nombre");
        System.out.println("Nombre: " + nombre);

        // Obtener una propiedad con valor predeterminado
        String ciudad = properties.getProperty("ciudad", "Ciudad desconocida");
        System.out.println("Ciudad: " + ciudad);

        // Mostrar todas las propiedades
        System.out.println("\nPropiedades:");
        properties.forEach((key, value) -> System.out.println(" - " + key + " = " + value));
    }
}
