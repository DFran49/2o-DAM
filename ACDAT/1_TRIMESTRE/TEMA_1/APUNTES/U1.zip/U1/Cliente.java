package U1;

import java.io.Serializable;

public class Cliente implements Serializable {
    private static final long serialVersionUID = 1L; // Agregado para compatibilidad con versiones futuras
    private String nombre;
    private transient String password; // Atributo transitorio

    public Cliente(String nombre, String password) {
        this.nombre = nombre;
        this.password = password;
    }

    @Override
    public String toString() {
        return (password == null ? "(No disponible)" : password) + " - " + nombre;
    }
}
