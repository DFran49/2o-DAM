package U1;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class EjemploBufferedOutputStream {
    public static void main(String[] args) {
        String nombreArchivo = "datos.bin";

        // Datos para escribir
        int entero = 12345;
        float decimalFloat = 3.14f;
        double decimalDouble = 2.71828;
        String texto = "Este es un ejemplo de texto.";

        try (BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(nombreArchivo))) {
            // Convertir y escribir un entero (4 bytes)
            bos.write(intToBytes(entero));
            System.out.println("Entero 12345 escrito correctamente.");

            // Convertir y escribir un número decimal (float, 4 bytes)
            bos.write(floatToBytes(decimalFloat));
            System.out.println("Decimal (float) 3.14 escrito correctamente.");

            // Convertir y escribir un número decimal (double, 8 bytes)
            bos.write(doubleToBytes(decimalDouble));
            System.out.println("Decimal (double) 2.71828 escrito correctamente.");

            // Convertir y escribir una cadena de texto (variable en longitud)
            bos.write(texto.getBytes());
            System.out.println("Texto escrito correctamente.");

            // Aseguramos que todos los datos se escriban en el archivo
            bos.flush();
            System.out.println("Datos escritos correctamente en el archivo " + nombreArchivo);
        } catch (IOException e) {
            System.err.println("Error al escribir en el archivo: " + e.getMessage());
        }
    }

    // Método para convertir un entero a bytes (Big Endian)
    private static byte[] intToBytes(int value) {
        return new byte[] {
                (byte) (value >>> 24),
                (byte) (value >>> 16),
                (byte) (value >>> 8),
                (byte) value
        };
    }

    // Método para convertir un float a bytes (Big Endian)
    private static byte[] floatToBytes(float value) {
        int intBits = Float.floatToIntBits(value);
        return intToBytes(intBits);
    }

    // Método para convertir un double a bytes (Big Endian)
    private static byte[] doubleToBytes(double value) {
        long longBits = Double.doubleToLongBits(value);
        return new byte[] {
                (byte) (longBits >>> 56),
                (byte) (longBits >>> 48),
                (byte) (longBits >>> 40),
                (byte) (longBits >>> 32),
                (byte) (longBits >>> 24),
                (byte) (longBits >>> 16),
                (byte) (longBits >>> 8),
                (byte) longBits
        };
    }
}
