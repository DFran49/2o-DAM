package U1;

import java.io.FileWriter;
import java.io.IOException;

public class FileWriter2 {
    public static void main(String[] args) {
        String fileName = "archivo.txt";
        FileWriter writer = null;

        try {
            // El segundo parámetro "true" habilita el modo de adición, evitando que se
            // sobrescriba el contenido existente
            writer = new FileWriter(fileName, true);
            writer.write("Esta es una nueva línea agregada al archivo.");
            writer.write(System.lineSeparator()); // Nueva línea
            writer.flush();
            System.out.println("Se ha agregado información al archivo.");
        } catch (IOException e) {
            // Manejo de excepciones de entrada/salida, por ejemplo, errores de escritura
            System.err.println("Ocurrió un error al agregar información al archivo: " + e.getMessage());
        } finally {
            // El bloque finally se ejecuta siempre, tanto si se lanza una excepción como si no
            try {
                if (writer != null)
                    writer.close(); // Asegura el cierre del flujo para liberar recursos
            } catch (IOException e) {
                // Manejo de posibles excepciones al intentar cerrar el flujo
                System.err.println("No se pudo cerrar el flujo: " + e.getMessage());
            }
        }
    }
}

