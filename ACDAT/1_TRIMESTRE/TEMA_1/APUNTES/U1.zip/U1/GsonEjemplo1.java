package U1;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;

public class GsonEjemplo1 {
    public static void main(String[] args) {
        Gson gson = new Gson();
        String jsonString = "{\"nombre\": \"Juan\", \"edad\": 25}";

        try {
            Persona5 persona = gson.fromJson(jsonString, Persona5.class);
            System.out.println("Nombre: " + persona.getNombre());
            System.out.println("Edad: " + persona.getEdad());
        } catch (JsonSyntaxException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}

class Persona5 {
    private String nombre;
    private int edad;

    public String getNombre() { return nombre; }
    public int getEdad() { return edad; }
}

