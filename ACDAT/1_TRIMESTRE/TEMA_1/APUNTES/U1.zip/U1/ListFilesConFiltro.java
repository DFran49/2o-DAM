package U1;

import java.io.File;
import java.io.FilenameFilter;

public class ListFilesConFiltro {
    public static void main(String[] args) {
        String directorio = "c:\\java"; // Directorio en el que se desea buscar archivos

        // Crea un objeto FilenameFilter personalizado usando una expresión lambda
        FilenameFilter filtro = (dir, nombreArchivo) -> nombreArchivo.endsWith(".java");
 /* --- OTRA FORMA DE HACERLO SIN UTILIZAR EXPRESIONES LAMBDA ---
        FilenameFilter filtro = new FilenameFilter() {
            @Override
            public boolean accept(File directorio, String nombreArchivo) {
                return nombreArchivo.endsWith(".java");
            }
        };
 */

        // Obtener una lista de archivos que cumplen con el criterio definido en el filtro
        File dir = new File(directorio);
        String[] archivosFiltrados = dir.list(filtro);

        // Imprimir los nombres de los archivos que cumplen con el criterio
        if (archivosFiltrados != null && archivosFiltrados.length > 0) {
            System.out.println("Archivos con extensión .java en el directorio " + directorio + ":");
            for (String nombreArchivo : archivosFiltrados)
                System.out.println(" - " + nombreArchivo);
        } else {
            System.out.println("No se encontraron archivos que cumplan con el criterio.");
        }
    }
}
