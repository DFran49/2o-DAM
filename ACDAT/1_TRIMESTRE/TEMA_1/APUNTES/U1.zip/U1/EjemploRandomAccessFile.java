package U1;

import java.io.IOException;
import java.io.RandomAccessFile;

public class EjemploRandomAccessFile {
    public static void main(String[] args) {
        String archivo = "archivo.dat";

        try (RandomAccessFile raFile = new RandomAccessFile(archivo, "rw")) {
            // Escribir datos
            raFile.writeBoolean(true);
            raFile.writeInt(42);
            raFile.writeDouble(3.14159);

            // Leer datos
            raFile.seek(0); // Volver al inicio del archivo
            boolean valorBooleano = raFile.readBoolean();
            int valorEntero = raFile.readInt();
            double valorDouble = raFile.readDouble();

            // Mostrar los datos leídos
            System.out.println("Valor booleano: " + valorBooleano);
            System.out.println("Valor entero: " + valorEntero);
            System.out.println("Valor double: " + valorDouble);
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
