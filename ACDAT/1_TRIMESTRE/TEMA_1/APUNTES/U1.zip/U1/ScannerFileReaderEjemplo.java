package U1;

import java.io.FileReader;
import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Scanner;

public class ScannerFileReaderEjemplo {
    public static void main(String[] args) {
        // Ruta del archivo
        String rutaArchivo = "salida.txt";

        // Bloque try-with-resources para asegurar el cierre automático del FileReader y Scanner
        try (FileReader fr = new FileReader(rutaArchivo);
             Scanner scanner = new Scanner(fr)) {
            // Leer y analizar diferentes tipos de datos desde el archivo
            while (scanner.hasNext()) {
                if (scanner.hasNextInt()) {
                    int numeroEntero = scanner.nextInt();
                    System.out.println("Entero: " + numeroEntero);
                } else if (scanner.hasNextDouble()) {
                    double numeroDouble = scanner.nextDouble();
                    System.out.println("Double: " + numeroDouble);
                } else if (scanner.hasNextFloat()) {
                    float numeroFloat = scanner.nextFloat();
                    System.out.println("Float: " + numeroFloat);
                } else if (scanner.hasNextBoolean()) {
                    boolean valorBooleano = scanner.nextBoolean();
                    System.out.println("Booleano: " + valorBooleano);
                } else { // Si no es ninguno de los tipos anteriores, asumimos que es una cadena
                    String texto = scanner.next();
                    System.out.println("Cadena: " + texto);
                }
            }
        } catch (InputMismatchException e) {
            System.err.println("Error: tipo de dato no coincidente - " + e.getMessage());
        } catch (IOException e) {
            System.err.println("Error al leer el archivo: " + e.getMessage());
        }
    }
}
