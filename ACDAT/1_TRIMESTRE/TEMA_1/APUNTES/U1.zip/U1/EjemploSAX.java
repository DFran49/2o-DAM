package U1;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import java.io.File;
import java.io.IOException;

class GestionContenido extends DefaultHandler {
    private boolean bId = false;
    private boolean bNombre = false;
    private boolean bApellidos = false;
    private boolean bDepartamento = false;
    private boolean bSueldo = false;

    @Override
    public void startDocument() {
        System.out.println("*********** Comienzo del documento XML ***********");
    }

    @Override
    public void endDocument() {
        System.out.println("*********** Final del documento XML ***********");
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) {
        switch (qName.toLowerCase()) {
            case "id":
                bId = true;
                break;
            case "nombre":
                bNombre = true;
                break;
            case "apellidos":
                bApellidos = true;
                break;
            case "departamento":
                bDepartamento = true;
                break;
            case "sueldo":
                bSueldo = true;
                break;
        }
    }

    @Override
    public void characters(char[] ch, int start, int length) {
        String content = new String(ch, start, length).trim();
        if (bId) {
            System.out.println("ID: " + content);
            bId = false;
        } else if (bNombre) {
            System.out.println(" - Nombre: " + content);
            bNombre = false;
        } else if (bApellidos) {
            System.out.println(" - Apellidos: " + content);
            bApellidos = false;
        } else if (bDepartamento) {
            System.out.println(" - Departamento: " + content);
            bDepartamento = false;
        } else if (bSueldo) {
            System.out.println(" - Sueldo: " + content);
            bSueldo = false;
        }
    }

    @Override
    public void endElement(String uri, String localName, String qName) {
        // Manejo del final de elementos si es necesario
    }

    @Override
    public void error(SAXParseException e) throws SAXException {
        System.out.println("Error: " + e.getMessage());
    }

    @Override
    public void warning(SAXParseException e) throws SAXException {
        System.out.println("Advertencia: " + e.getMessage());
    }
}

public class EjemploSAX {
    public static void main(String[] args) {
        try {
            SAXParserFactory factory = SAXParserFactory.newInstance();
            SAXParser saxParser = factory.newSAXParser();
            GestionContenido handler = new GestionContenido();
            saxParser.parse(new File("empleados.xml"), handler);
        } catch (SAXException e) {
            System.out.println("Error SAX: " + e.getMessage());
        } catch (IOException e) {
            System.out.println("Error IO: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
