package U1;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class GsonFileEjemplo {
    public static void main(String[] args) {
        try (FileReader fileReader = new FileReader("persona.json")) {
            JsonObject jsonObject = JsonParser.parseReader(fileReader).getAsJsonObject();
            jsonObject.addProperty("edad", 30);

            try (FileWriter fileWriter = new FileWriter("persona_modificado.json")) {
                new Gson().toJson(jsonObject, fileWriter);
            }

            System.out.println("Archivo JSON modificado y guardado.");
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
