package U1;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class EjemploLecturaCSV {
    public static void main(String[] args) {
        String rutaArchivo = "archivo.csv";

        // Bloque try-with-resources para asegurar el cierre del BufferedReader
        try (BufferedReader bufferLector = new BufferedReader(new FileReader(rutaArchivo))) {
            String linea;

            // Leer y procesar el encabezado (primera línea)
            if ((linea = bufferLector.readLine()) != null) {
                String[] camposEncabezado = linea.split(",");
                System.out.println("Encabezado:");
                System.out.println(String.join(" | ", camposEncabezado)); // Imprimir encabezado en formato tabla
            }

            // Leer y procesar los registros
            System.out.println("\nRegistros:");
            while ((linea = bufferLector.readLine()) != null) {
                String[] campos = linea.split(",");
                System.out.println(String.join(" | ", campos)); // Imprimir cada registro en formato tabla
            }
        } catch (IOException e) {
            System.err.printf("Error al leer el archivo '%s': %s%n", rutaArchivo, e.getMessage());
        }
    }
}
