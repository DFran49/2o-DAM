package U1;

import com.google.gson.Gson;

public class GsonEjemplo2 {
    public static void main(String[] args) {
        Gson gson = new Gson();
        Persona6 persona = new Persona6("María", 30);

        try {
            String jsonString = gson.toJson(persona);
            System.out.println(jsonString);
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}

class Persona6 {
    private String nombre;
    private int edad;

    public Persona6() { }

    public Persona6(String nombre, int edad) {
        this.nombre = nombre;
        this.edad = edad;
    }
}
