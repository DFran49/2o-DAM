package U1;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class EscribirFicheroConFormato1 {
    public static void main(String[] args) {
        String archivoSalida = "salida.txt";

        // Uso de try-with-resources para abrir y manejar recursos de escritura
        try (FileWriter fw = new FileWriter(archivoSalida);
           BufferedWriter bw = new BufferedWriter(fw);
           PrintWriter pw = new PrintWriter(bw)) {
            // Escribe líneas de texto formateadas en el archivo
            pw.println("Nombre: Juan Moreno");
            pw.println("Edad: 30");
            pw.printf("Peso: %.2f kg%n", 75.5);
            pw.printf("Altura: %.2f cm%n", 180.0);

            System.out.println("Archivo de salida creado con éxito.");
        } catch (IOException e) {
            System.err.println("Error al escribir en el archivo: " + e.getMessage());
        }
    }
}
