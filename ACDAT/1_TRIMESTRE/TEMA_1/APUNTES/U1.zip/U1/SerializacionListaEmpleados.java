package U1;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.security.AnyTypePermission;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

// Clase Empleado
class Empleado4 {
    private int id;
    private String nombre;
    private String apellidos;
    private String departamento;
    private double sueldo;

    public Empleado4(int id, String nombre, String apellidos, String departamento, double sueldo) {
        this.id = id;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.departamento = departamento;
        this.sueldo = sueldo;
    }

    @Override
    public String toString() {
        return "Empleado{" + "id=" + id + ", nombre='" + nombre + '\'' + ", apellidos='" +
                apellidos + '\'' + ", departamento='" + departamento + '\'' + ", sueldo=" + sueldo + '}';
    }
}

// Clase para manejar la lista de empleados
class ListaEmpleados {
    private List<Empleado4> empleados = new ArrayList<>();

    public void agregarEmpleado(Empleado4 empleado) {
        empleados.add(empleado);
    }

    public List<Empleado4> obtenerEmpleados() {
        return empleados;
    }
}

// Clase principal para serializar y deserializar
public class SerializacionListaEmpleados {
    private static final String ARCHIVO_XML = "empleados.xml";

    public static void main(String[] args) {
        ListaEmpleados listaEmpleados = new ListaEmpleados();
        listaEmpleados.agregarEmpleado(new Empleado4(1, "Juan", "Pérez", "Ventas", 50000.0));
        listaEmpleados.agregarEmpleado(new Empleado4(2, "María", "López", "Recursos Humanos", 55000.0));
        listaEmpleados.agregarEmpleado(new Empleado4(3, "Pedro", "González", "TI", 60000.0));

        serializarEmpleados(listaEmpleados);
        ListaEmpleados empleadosDeserializados = deserializarEmpleados();

        if (empleadosDeserializados != null)
            empleadosDeserializados.obtenerEmpleados().forEach(System.out::println);
    }

    // Método para serializar una lista de empleados a XML
    private static void serializarEmpleados(ListaEmpleados listaEmpleados) {
        XStream xstream = new XStream();
        xstream.alias("empleados", ListaEmpleados.class);
        xstream.alias("empleado", Empleado.class);
        xstream.addImplicitCollection(ListaEmpleados.class, "empleados");

        try (FileOutputStream fos = new FileOutputStream(ARCHIVO_XML)) {
            xstream.toXML(listaEmpleados, fos);
            System.out.println("Serialización completada.");
        } catch (IOException e) {
            System.out.println("Error al serializar la lista de empleados: " + e.getMessage());
        }
    }

    // Método para deserializar una lista de empleados desde un archivo XML
    private static ListaEmpleados deserializarEmpleados() {
        XStream xstream = new XStream();
        xstream.addPermission(AnyTypePermission.ANY);
        xstream.alias("empleados", ListaEmpleados.class);
        xstream.alias("empleado", Empleado.class);
        xstream.addImplicitCollection(ListaEmpleados.class, "empleados");

        try (FileInputStream fis = new FileInputStream(ARCHIVO_XML)) {
            System.out.println("Deserialización completada.");
            return (ListaEmpleados) xstream.fromXML(fis);
        } catch (IOException e) {
            System.out.println("Error al deserializar la lista de empleados: " + e.getMessage());
            return null;
        }
    }
}
