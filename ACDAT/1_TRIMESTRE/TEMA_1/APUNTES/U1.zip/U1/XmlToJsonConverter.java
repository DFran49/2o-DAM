package U1;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Map;
import org.json.JSONObject;
import org.json.XML;

public class XmlToJsonConverter {
    public static void main(String[] args) {
        String filePath = "personas.xml"; // Ruta del archivo XML
        StringBuilder xmlContenido = new StringBuilder(); // Para almacenar el contenido del archivo

        // Leer el archivo usando BufferedReader
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String linea;

            while ((linea = reader.readLine()) != null)
                xmlContenido.append(linea);

            // Convertir XML a un objeto JSONObject utilizando org.json
            JSONObject objetoJSON = XML.toJSONObject(xmlContenido.toString());

            // Convertir el objeto JSONObject a un Map
            Map<String, Object> jsonMap = objetoJSON.toMap();

            // Crear un objeto Gson con formato bonito (pretty printing)
            Gson gson = new GsonBuilder().setPrettyPrinting().create();

            // Convertir el Map a una cadena JSON con formato
            String salidaJSON = gson.toJson(jsonMap);

            // Imprimir el JSON resultante
            System.out.println(salidaJSON);
        } catch (IOException e) {
            System.out.println("Error al leer el archivo XML: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Error durante la conversión de XML a JSON: " + e.getMessage());
        }
    }
}
