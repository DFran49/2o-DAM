package U1;

import java.io.Serializable;

public abstract class Figura implements Serializable {
    protected int x;
    protected int y;

    public Figura(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public abstract double area();
}
