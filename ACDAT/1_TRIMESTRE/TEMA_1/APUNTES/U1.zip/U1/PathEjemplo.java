package U1;

import java.nio.file.*; // Importar las clases Path y Paths

public class PathEjemplo {
    public static void main(String[] args) {
        // Crear una ruta usando Paths.get()
        Path path = Paths.get("C:", "Users", "Usuario", "Documents", "archivo.txt");

        // Mostrar información sobre la ruta
        System.out.println("Ruta completa: " + path); // path.toString()
        System.out.println("Nombre del archivo: " + path.getFileName());
        System.out.println("Directorio padre: " + path.getParent());
        System.out.println("Número de elementos en la ruta: " + path.getNameCount());

        // Iterar a través de los componentes de la ruta
        System.out.println("Componentes de la ruta:");
        for (int i = 0; i < path.getNameCount(); i++)
            System.out.println(" - " + (i + 1) + ": " + path.getName(i));

        // Comprobar si la ruta es absoluta
        System.out.println("¿Ruta absoluta? " + (path.isAbsolute() ? "SI" : "NO"));

        // Resolviendo una ruta relativa
        Path relativePath = Paths.get("subdirectorio", "archivo2.txt");
        Path resolvedPath = path.resolve(relativePath);
        System.out.println("Ruta resuelta: " + resolvedPath);

        // Comprobar si una ruta comienza con otra ruta
        boolean startsWith = path.startsWith(Paths.get("C:", "Users"));
        System.out.println("¿La ruta comienza con 'C:\\Users'? " + (startsWith ? "SI" : "NO"));
    }
}
