package jl;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class EjemploDatabaseMetaData2 {
    public static void main(String[] args) {
        String url = "jdbc:mariadb://localhost/", usuario = "root", clave = "root";

        try (Connection conexion = DriverManager.getConnection(url, usuario, clave)) {
            DatabaseMetaData metaData = conexion.getMetaData();

            // Información general sobre el SGBD
            System.out.println("Nombre del producto............: " + metaData.getDatabaseProductName());
            System.out.println("Versión del producto...........: " + metaData.getDatabaseProductVersion());
            System.out.println("Nombre del controlador JDBC....: " + metaData.getDriverName());
            System.out.println("Versión del controlador JDBC...: " + metaData.getDriverVersion());
            System.out.println("Usuario........................: " + metaData.getUserName());

            // Listar tablas en la BD
            try (ResultSet tablas = metaData.getTables(null, null, null, new String[] { "TABLE" })) {
                System.out.println("\nTablas en las BD del servidor:");
                if (!tablas.next()) {
                    System.out.println("No se encontraron tablas en la base de datos.");
                } else {
                    do {
                        String nombreTabla = tablas.getString("TABLE_NAME");
                        System.out.println("\nTabla: " + nombreTabla);
                        System.out.println("*******************************************************************");

                        // Listar columnas de la tabla
                        System.out.println("Columnas de la tabla " + nombreTabla + ":");
                        try (ResultSet columnas = metaData.getColumns(null, null, nombreTabla, null)) {
                            while (columnas.next()) {
                                String nombreColumna = columnas.getString("COLUMN_NAME");
                                String tipoDato = columnas.getString("TYPE_NAME");
                                System.out.println("  " + nombreColumna + " : " + tipoDato);
                            }
                        }

                        // Obtener claves primarias
                        System.out.println("Columnas que conforman la clave primaria de la tabla " + nombreTabla + ":");
                        try (ResultSet clavesPrimarias = metaData.getPrimaryKeys(null, null, nombreTabla)) {
                            while (clavesPrimarias.next()) {
                                String nombreClavePrimaria = clavesPrimarias.getString("COLUMN_NAME");
                                System.out.println("  --> " + nombreClavePrimaria);
                            }
                        }

                        // Obtener claves foráneas
                        System.out.println("Claves foráneas referenciando la tabla " + nombreTabla + ":");
                        try (ResultSet clavesForaneas = metaData.getImportedKeys(null, null, nombreTabla)) {
                            while (clavesForaneas.next()) {
                                String nomTabFor = clavesForaneas.getString("PKTABLE_NAME");
                                String nomColFor = clavesForaneas.getString("FKCOLUMN_NAME");
                                System.out.println("  Desde la tabla " + nomTabFor + ", columna: " + nomColFor);
                            }
                        }
                    } while (tablas.next());
                }
            }
        } catch (SQLException e) {
            System.out.println("Error de SQL: " + e.getMessage());
        }
    }
}
