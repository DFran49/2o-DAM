package jl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement; 
import java.sql.SQLException; 

public class InsertaDepPreparedStatement {
    public static void main(String[] args) {
        if (args.length == 3) { // Recuperar argumentos de main
            String idDep = args[0], nombre = args[1], localidad = args[2];
            
            try (Connection con = DriverManager.getConnection("jdbc:mariadb://localhost/mydb", "mydb", "password")) {
                // Validar que el ID del departamento sea un entero
                int idDepartamento;
                try {
                    idDepartamento = Integer.parseInt(idDep);
                } catch (NumberFormatException e) {
                    System.out.println("Error: el ID del departamento debe ser un número entero.");
                    return;
                }

                String sql = "INSERT INTO departamentos VALUES (?, ?, ?)";
                try (PreparedStatement sentencia = con.prepareStatement(sql)) {
                    sentencia.setInt(1, idDepartamento); // Convierte la cadena a int
                    sentencia.setString(2, nombre);
                    sentencia.setString(3, localidad);
                    int filas = sentencia.executeUpdate();
                    System.out.println("Filas afectadas: " + filas);
                } catch (SQLException e) {
                    System.out.println("Error al insertar el departamento:");
                    System.out.println("Mensaje:    " + e.getMessage());
                    System.out.println("SQL estado: " + e.getSQLState());
                    System.out.println("Cód. error: " + e.getErrorCode());
                }
            } catch (SQLException e) { 
                System.out.println("HA OCURRIDO UNA EXCEPCIÓN:");
                System.out.println("Mensaje:    " + e.getMessage());
                System.out.println("SQL estado: " + e.getSQLState());
                System.out.println("Cód. error: " + e.getErrorCode());
            }
        } else {
            System.out.println("Error: se deben pasar tres parámetros al llamar al programa.");
        }
    }
}
