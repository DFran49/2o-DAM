package jl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SQLiteEjemplo {
    public static void main(String[] args) {
        // Ruta de la BD SQLite (puede ser una ruta absoluta o relativa)
        String dbURL = "jdbc:sqlite:C:\\java\\mydb.db"; // En lugar de utilizar \\ se puede utilizar /

        // Declaraciones JDBC
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            Class.forName("org.sqlite.JDBC"); // Paso 1: Cargar el controlador JDBC de SQLite – NO NECESARIO

            connection = DriverManager.getConnection(dbURL); // Paso 2: Establecer la conexión con la BD

            statement = connection.createStatement(); // Paso 3: Crear una declaración SQL

            String sqlQuery = "SELECT * FROM departamentos"; // Paso 4: Ejecutar una consulta SQL
            resultSet = statement.executeQuery(sqlQuery);

            while (resultSet.next()) // Paso 5: Procesar los resultados
                System.out.println("ID: " + resultSet.getInt("id_departamento") + ", Nombre: " +
                        resultSet.getString("nombre") + ", Ciudad: " + resultSet.getString("localidad"));
        } catch (ClassNotFoundException e) {
            System.out.println("Error al cargar el controlador JDBC: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("Error de SQL: " + e.getMessage());
        } finally {
            try { // Paso 6: Cerrar la conexión y liberar recursos
                if (resultSet != null)
                    resultSet.close();
                if (statement != null)
                    statement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                System.out.println("Error al cerrar la conexión y liberar recursos: " + e.getMessage());
            }
        }
    }
}

