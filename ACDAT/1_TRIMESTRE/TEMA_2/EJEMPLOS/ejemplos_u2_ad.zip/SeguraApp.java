package jl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class SeguraApp {
    public static void main(String[] args) {
        String userInput = "'; DROP TABLE usuarios; --"; // Input malicioso del usuario

        // Uso de una sentencia preparada para evitar la inyección SQL
        try (Connection connection = DriverManager.getConnection("jdbc:mariadb://localhost/base_de_datos", "usuario", "contraseña")) {
            // Uso de una sentencia preparada para evitar la inyección SQL
            String query = "SELECT * FROM usuarios WHERE nombre = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, userInput); // Parámetro 1 (el primero), no empieza en 0

                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    // Procesamiento de los resultados
                    while (resultSet.next()) {
                        System.out.println("Nombre: " + resultSet.getString("nombre"));
                        // Otros campos...
                    }
                }
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
