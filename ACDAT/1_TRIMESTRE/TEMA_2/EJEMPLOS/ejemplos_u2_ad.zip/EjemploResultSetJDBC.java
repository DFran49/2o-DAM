package jl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet; 
import java.sql.SQLException;
import java.sql.Statement;

public class EjemploResultSetJDBC {
    public static void main(String[] args) {
        String url = "jdbc:mariadb://localhost/mydb", usuario = "mydb", clave = "password";

        try (Connection con = DriverManager.getConnection(url, usuario, clave);
             Statement stm = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE)) {
            String consulta = "SELECT id, nombre, salario FROM empleados2";
            ResultSet rs = stm.executeQuery(consulta);

            while (rs.next()) { // Moverse a través de los resultados
                int id = rs.getInt("id"); // Acceso por nombre o índice
                String nombre = rs.getString("nombre"); 
                double salario = rs.getDouble("salario"); 
                System.out.println("ID: " + id + ", Nombre: " + nombre + ", Salario: " + salario);
            }

            // Verificar si hay al menos 2 filas antes de intentar moverse a la segunda
            rs.last(); // Mover al final para contar las filas
            int numeroFilas = rs.getRow();
            if (numeroFilas >= 2) {
                rs.absolute(2); // Mover al segundo registro
                rs.updateDouble("salario", 75000.0); // Actualizar el salario de la segunda fila
                rs.updateRow(); // Aplicar la actualización
                System.out.println("Salario del segundo empleado actualizado a 75000.0.");
            } else
                System.out.println("No hay suficientes filas en la tabla para realizar la actualización.");

            rs.close(); // Cerrar el ResultSet
        } catch (SQLException e) {
            System.out.println("Error de SQL: " + e.getMessage());
        }
    }
}
