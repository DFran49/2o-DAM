package jl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class EjemplogetPrimaryKeys {
    public static void main(String[] args) {
        // Establecer la conexión con la BD
        try (Connection con = DriverManager.getConnection("jdbc:mariadb://localhost/mydb", "mydb", "password");
             ResultSet pk = con.getMetaData().getPrimaryKeys("mydb", null, "departamentos")) {
            System.out.println("======================================");
            System.out.println("= CLAVE PRIMARIA TABLA DEPARTAMENTOS =");
            System.out.println("======================================");

            StringBuilder pkDep = new StringBuilder(); // Usar StringBuilder para mejorar la eficiencia
            String separador = "";

            while (pk.next()) {
                pkDep.append(separador).append(pk.getString("COLUMN_NAME")); // Concatenar nombres de columnas
                separador = " + "; // Separador para los nombres de columnas
            }
            System.out.println("Clave primaria: " + pkDep.toString());
        } catch (SQLException e) {
            System.out.println("Error de SQL: " + e.getMessage());
        }
    }
}
