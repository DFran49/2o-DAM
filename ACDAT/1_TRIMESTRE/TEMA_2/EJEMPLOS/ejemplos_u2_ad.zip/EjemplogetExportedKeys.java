package jl;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class EjemplogetExportedKeys {
    public static void main(String[] args) {
        String url = "jdbc:mariadb://localhost/mydb", usuario = "mydb", clave = "password";

        try (Connection conexion = DriverManager.getConnection(url, usuario, clave)) {
            DatabaseMetaData dbmd = conexion.getMetaData(); // Crear objeto DatabaseMetaData

            System.out.println("=================================================");
            System.out.println("= CLAVES AJENAS QUE REFERENCIAN A DEPARTAMENTOS =");
            System.out.println("=================================================");

            try (ResultSet fk = dbmd.getExportedKeys("mydb", null, "departamentos")) {
                while (fk.next()) {
                    String fkName = fk.getString("FKCOLUMN_NAME");
                    String pkName = fk.getString("PKCOLUMN_NAME");
                    String pkTableName = fk.getString("PKTABLE_NAME");
                    String fkTableName = fk.getString("FKTABLE_NAME");

                    System.out.printf("Tabla PK: %s, Clave Primaria: %s %n", pkTableName, pkName);
                    System.out.printf("Tabla FK: %s, Clave Ajena: %s %n", fkTableName, fkName);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error de SQL: " + e.getMessage());
        }
    }
}
