package jl;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import java.sql.Connection;
import java.sql.SQLException;

public class HikariCPConnectionPool {
    private static final HikariDataSource dataSource;

    static {
        HikariConfig config = new HikariConfig(); // Configuración del pool de conexiones
        config.setJdbcUrl("jdbc:mariadb://localhost/mydb");
        config.setUsername("mydb");
        config.setPassword("password");
        config.setDriverClassName("org.mariadb.jdbc.Driver");

        // Configuración adicional del pool
        config.setMinimumIdle(5);  // Número mínimo de conexiones inactivas
        config.setMaximumPoolSize(10); // Número máximo de conexiones en el pool
        config.setIdleTimeout(30000); // Tiempo máximo de inactividad de una conexión antes de ser eliminada

        dataSource = new HikariDataSource(config);
    }

    // Constructor privado para evitar instancias
    private HikariCPConnectionPool() {
    }

    // Obtener una conexión del pool
    public static Connection getConnection() throws SQLException {
        return dataSource.getConnection();
    }

    // Devolver conexión al pool
    public static void closeConnection(Connection connection) throws SQLException {
        if (connection != null)
            connection.close();  // Las conexiones se devuelven automáticamente al pool
    }

    // Proporciona el estado actual del pool
    public static String getPoolStatus() {
        return String.format("Conexiones activas: %d, Inactivas: %d, Totales: %d",
                dataSource.getHikariPoolMXBean().getActiveConnections(),
                dataSource.getHikariPoolMXBean().getIdleConnections(),
                dataSource.getHikariPoolMXBean().getTotalConnections());
    }
}
