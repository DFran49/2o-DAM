package jl;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class EjecutarScriptSQL {
    public static void main(String[] args) {
        String url = "jdbc:mariadb://localhost/mydb?allowMultiQueries=true";
        String archivoScript = "ruta_del_script.sql";

        try (Connection conexion = DriverManager.getConnection(url, "mydb", "password");
             Statement statement = conexion.createStatement();
             BufferedReader br = new BufferedReader(new FileReader(archivoScript))) {
            // Leer el archivo de script SQL línea por línea
            String linea;
            StringBuilder scriptCompleto = new StringBuilder();
            while ((linea = br.readLine()) != null)
                scriptCompleto.append(linea).append("\n");

            // Ejecutar el script SQL que contiene múltiples sentencias
            boolean tieneResultados = statement.execute(scriptCompleto.toString());

            if (!tieneResultados)
                System.out.println("El script se ejecutó con éxito.");
            else
                System.out.println("El script devolvió un conjunto de resultados.");
        } catch (SQLException e) {
            System.out.println("Error de SQL: " + e.getMessage());
        } catch (IOException e) {
            System.out.println("Error al leer el fichero: " + e.getMessage());
        }
    }
}
