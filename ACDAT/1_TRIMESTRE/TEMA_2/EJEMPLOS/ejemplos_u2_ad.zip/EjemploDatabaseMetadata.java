package jl;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class EjemploDatabaseMetadata {
    public static void main(String[] args) {
        try (Connection con = DriverManager.getConnection("jdbc:mariadb://localhost/mydb", "mydb", "password")) {
            DatabaseMetaData dbmd = con.getMetaData(); // Crear objeto DatabaseMetaData
            
            // Obtener y mostrar información básica de la BD
            String nombre = dbmd.getDatabaseProductName();
            String driver = dbmd.getDriverName();
            String url = dbmd.getURL();
            String usuario = dbmd.getUserName();

            System.out.println("========================================");
            System.out.println("=  INFORMACIÓN SOBRE LA BASE DE DATOS  =");
            System.out.println("========================================");
            System.out.printf("Nombre del producto : %s %n", nombre);
            System.out.printf("Driver utilizado    : %s %n", driver);
            System.out.printf("URL de conexión     : %s %n", url);
            System.out.printf("Usuario conectado   : %s %n", usuario);

            // Obtener información de las tablas
            System.out.println("========================================");
            System.out.println("=  TABLAS Y VISTAS EN LA BASE DE DATOS =");
            System.out.println("========================================");

            // Obtener solo las tablas y vistas
            String[] tipos = {"TABLE", "VIEW"};
            try (ResultSet resul = dbmd.getTables("mydb", null, null, tipos)) {
                while (resul.next()) {
                    String catalogo = resul.getString("TABLE_CAT"); // getString(1)
                    String esquema = resul.getString("TABLE_SCHEM"); // getString(2)
                    String tabla = resul.getString("TABLE_NAME"); // getString(3)
                    String tipo = resul.getString("TABLE_TYPE"); // getString(4)
                    System.out.printf("Tipo: %s - Catálogo: %s, Esquema: %s, Tabla: %s %n", tipo, catalogo, esquema, tabla);
                }
            } catch (SQLException e) {
                System.out.println("Error al obtener las tablas: " + e.getMessage());
            }
        } catch (SQLException e) {
            System.out.println("Error de SQL: " + e.getMessage());
        }
    }
}
