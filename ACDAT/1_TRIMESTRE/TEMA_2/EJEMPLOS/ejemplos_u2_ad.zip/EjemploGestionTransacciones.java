package jl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException; 
import java.sql.Statement; 

public class EjemploGestionTransacciones {
    public static void main(String[] args) {
        Connection conexion = null;
        String jdbcUrl = "jdbc:mariadb://localhost/mydb";

        try {
            conexion = DriverManager.getConnection(jdbcUrl, "mydb", "password");
            crearTabla(conexion); // Crear una tabla

            conexion.setAutoCommit(false); // Deshabilitar la confirmación automática

            // Insertar un registro
            insertarRegistro(conexion, "Juan", "Pérez");
            // Modificar un registro
            modificarRegistro(conexion, 1, "Pedro", "Gómez");
            // Eliminar un registro
            eliminarRegistro(conexion, 1);

            // Confirmar todas las sentencias una vez ejecutadas sin que se produzca un error
            conexion.commit();
            conexion.setAutoCommit(true); // Se vuelve a poner el autocommit, para el resto de la aplicación
            System.out.println("Transacción ejecutada con éxito.");
        } catch (SQLException e) {
            System.out.println();
            mostrarMensajeError(e);
            try { // Revertir todas las transacciones en caso de error
                if (conexion != null)
                    conexion.rollback(); // Si algo falla se hace "ROLLBACK"
            } catch (SQLException ex) {
                mostrarMensajeError(e);
            }
        } finally {
            try { // Cerrar la conexión
                if (conexion != null)
                    conexion.close();
            } catch (SQLException e) {
                mostrarMensajeError(e);
            }
        }
    }

    private static void crearTabla(Connection conexion) throws SQLException {
        String crearTablaSQL = "CREATE TABLE IF NOT EXISTS usuarios (id INT AUTO_INCREMENT, nombre VARCHAR(50), apellido VARCHAR(50), PRIMARY KEY (id))";
        try (Statement statement = conexion.createStatement()) {
            statement.execute(crearTablaSQL);
        }
    }

    private static void insertarRegistro(Connection conexion, String nombre, String apellido) throws SQLException {
        String insertarSQL = "INSERT INTO usuarios (nombre, apellido) VALUES (?, ?)";
        try (PreparedStatement pstmt = conexion.prepareStatement(insertarSQL)) {
            pstmt.setString(1, nombre);
            pstmt.setString(2, apellido);
            pstmt.executeUpdate();
        }
    }

    private static void modificarRegistro(Connection conexion, int id, String nuevoNombre, String nuevoApellido) throws SQLException {
        String modificarSQL = "UPDATE usuarios SET nombre = ?, apellido = ? WHERE id = ?";
        try (PreparedStatement pstmt = conexion.prepareStatement(modificarSQL)) {
            pstmt.setString(1, nuevoNombre);
            pstmt.setString(2, nuevoApellido);
            pstmt.setInt(3, id);
            pstmt.executeUpdate();
        }
    }

    private static void eliminarRegistro(Connection conexion, int id) throws SQLException {
        String eliminarSQL = "DELETE FROM usuarios WHERE id = ?";
        try (PreparedStatement pstmt = conexion.prepareStatement(eliminarSQL)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        }
    }

    private static void mostrarMensajeError(SQLException e) {
        System.out.println("HA OCURRIDO UNA EXCEPCIÓN:");
        System.out.println("Mensaje:    " + e.getMessage());
        System.out.println("SQL estado: " + e.getSQLState());
        System.out.println("Cód. error: " + e.getErrorCode());
    }
}
