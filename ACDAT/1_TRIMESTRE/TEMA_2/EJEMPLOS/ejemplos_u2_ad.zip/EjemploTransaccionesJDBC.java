package jl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Savepoint;
import java.sql.Statement;

public class EjemploTransaccionesJDBC {
    public static void main(String[] args) {
        String url = "jdbc:mariadb://localhost/mydb";
        Connection conexion = null;
        Savepoint savepoint = null;

        try {
            conexion = DriverManager.getConnection(url, "mydb", "password");
            // Crear una tabla en la BD
            createTable(conexion);

            // Desactivar el autocommit para controlar las transacciones
            conexion.setAutoCommit(false);

            // Insertar datos en la tabla
            insertData(conexion, "Juan", 30);

            // Crear un punto de guardado
            savepoint = conexion.setSavepoint("puntoGuardado");

            // Intentar insertar datos con un error (nombre nulo)
            insertData(conexion, null, 25);

            // Confirmar la transacción
            conexion.commit();
            System.out.println("Transacción completada con éxito.");
        } catch (SQLException e) {
            System.err.println("Error SQL: " + e.getMessage());
            try {
                if (conexion != null && savepoint != null) {
                    conexion.rollback(savepoint); // Volver al punto de guardado en caso de error
                    System.err.println("Rollback al punto de guardado.");
                }
            } catch (SQLException e2) {
                System.err.println("Error al hacer rollback al punto de salvaguarda.");
            }
        } finally {
            try {
                if (conexion != null)
                    conexion.close();
            } catch (SQLException e) {
                System.err.println("Error al cerrar la conexión.");
            }
        }
    }

    private static void createTable(Connection conexion) throws SQLException {
        String createTableSQL = "CREATE TABLE IF NOT EXISTS personas ("
                + "id INT AUTO_INCREMENT PRIMARY KEY,"
                + "nombre VARCHAR(255) NOT NULL,"
                + "edad INT NOT NULL)";
        try (Statement statement = conexion.createStatement()) {
            statement.executeUpdate(createTableSQL);
        }
    }

    private static void insertData(Connection conexion, String nombre, int edad) throws SQLException {
        String insertSQL = "INSERT INTO personas (nombre, edad) VALUES (?, ?)";
        try (PreparedStatement preparedStatement = conexion.prepareStatement(insertSQL)) {
            preparedStatement.setString(1, nombre);
            preparedStatement.setInt(2, edad);
            preparedStatement.executeUpdate();
        }
    }
}
