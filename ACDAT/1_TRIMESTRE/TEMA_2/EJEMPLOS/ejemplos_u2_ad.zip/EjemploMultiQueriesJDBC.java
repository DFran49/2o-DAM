package jl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class EjemploMultiQueriesJDBC {
    public static void main(String[] args) {
        String url = "jdbc:mariadb://localhost/mydb?allowMultiQueries=true";

        try (Connection conexion = DriverManager.getConnection(url, "mydb", "password");
                Statement statement = conexion.createStatement()) {
            // Ejemplo de ejecución de múltiples consultas en una sola llamada
            String consultaSQL = "INSERT INTO departamentos VALUES (6, 'Marketing', 'Granada');" +
                    "INSERT INTO departamentos VALUES (7, 'Publicidad', 'Granada');";

            boolean resultado = statement.execute(consultaSQL);

            if (!resultado)
                System.out.println("Las sentencias se ejecutaron con éxito.");
            else
                System.out.println("Las sentencias devolvieron un conjunto de resultados.");
        } catch (SQLException e) {
            System.out.println("Error de SQL: " + e.getMessage());
        }
    }
}

