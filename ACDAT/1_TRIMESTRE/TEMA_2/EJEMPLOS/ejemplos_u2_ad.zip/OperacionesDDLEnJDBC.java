package jl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class OperacionesDDLEnJDBC {
    public static void main(String[] args) {
        String url = "jdbc:mariadb://localhost/", usuario = "root", clave = "root", nomBD = "nueva_bd";

        try (Connection conexion = DriverManager.getConnection(url, usuario, clave)) {
            // Crear una nueva BD
            try (Statement crearBaseDeDatosStmt = conexion.createStatement()) {
                String crearBaseDeDatosSQL = "CREATE DATABASE " + nomBD;
                crearBaseDeDatosStmt.executeUpdate(crearBaseDeDatosSQL);
                System.out.println("BD creada con éxito.");
            } catch (SQLException e) {
                System.out.println("Error al crear la BD '" + nomBD + "': " + e.getMessage());
                return; // Salir si hay error al crear la BD
            }

            // Usar la nueva BD
            String urlNuevaBD = url + nomBD;
            try (Connection nuevaConexion = DriverManager.getConnection(urlNuevaBD, usuario, clave);
                 Statement crearTablaStmt = nuevaConexion.createStatement()) {
                 
                // Crear una tabla en la nueva BD
                String crearTablaSQL = "CREATE TABLE ejemplo_tabla ("
                        + "id INT AUTO_INCREMENT PRIMARY KEY,"
                        + "nombre VARCHAR(255) NOT NULL,"
                        + "edad INT)";
                crearTablaStmt.executeUpdate(crearTablaSQL);
                System.out.println("Tabla creada con éxito en la nueva BD.");

                // Modificar la tabla (agregar una columna)
                String modificarTablaSQL = "ALTER TABLE ejemplo_tabla ADD COLUMN nuevo_campo VARCHAR(255)";
                crearTablaStmt.executeUpdate(modificarTablaSQL);
                System.out.println("Tabla modificada con éxito.");

                // Eliminar la tabla
                String eliminarTablaSQL = "DROP TABLE ejemplo_tabla";
                crearTablaStmt.executeUpdate(eliminarTablaSQL);
                System.out.println("Tabla eliminada con éxito.");
            } catch (SQLException e) {
                System.out.println("Error al realizar operaciones en la BD '" + nomBD + "': " + e.getMessage());
            }

            // Eliminar la nueva BD
            try (Statement eliminarBaseDeDatosStmt = conexion.createStatement()) {
                String eliminarBaseDeDatosSQL = "DROP DATABASE " + nomBD;
                eliminarBaseDeDatosStmt.executeUpdate(eliminarBaseDeDatosSQL);
                System.out.println("BD eliminada con éxito.");
            } catch (SQLException e) {
                System.out.println("Error al eliminar la BD '" + nomBD + "': " + e.getMessage());
            }
        } catch (SQLException e) {
            System.out.println("Error de SQL: " + e.getMessage());
        }
    }
}
