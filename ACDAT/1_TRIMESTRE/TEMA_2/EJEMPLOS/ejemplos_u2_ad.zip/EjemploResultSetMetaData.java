package jl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class EjemploResultSetMetaData {
    public static void main(String[] args) {
        String url = "jdbc:mariadb://localhost/mydb";

        try (Connection conexion = DriverManager.getConnection(url, "mydb", "password"); 
                Statement statement = conexion.createStatement()) {
            String consulta = "SELECT id, nombre, salario FROM empleados2";

            try (ResultSet resultSet = statement.executeQuery(consulta)) {
                if (!resultSet.isBeforeFirst()) { // Verificar si hay resultados
                    System.out.println("No se encontraron registros en la consulta.");
                } else {
                    ResultSetMetaData metaData = resultSet.getMetaData();
                    int columnCount = metaData.getColumnCount();
                    System.out.println("Número de columnas: " + columnCount);
                    System.out.println("Información de las columnas:");
                    for (int i = 1; i <= columnCount; i++) {
                        String nombreColumna = metaData.getColumnName(i);
                        String etiquetaColumna = metaData.getColumnLabel(i);
                        String tipoColumna = metaData.getColumnTypeName(i);
                        int tipoCodigo = metaData.getColumnType(i);
                        int tamanoVisualizacion = metaData.getColumnDisplaySize(i);
                        boolean permiteNulos = (metaData.isNullable(i) == ResultSetMetaData.columnNullable);
                        int precision = metaData.getPrecision(i);
                        int escala = metaData.getScale(i);

                        System.out.println("Columna " + i + ":");
                        System.out.println("   Nombre: " + nombreColumna);
                        System.out.println("   Etiqueta: " + etiquetaColumna);
                        System.out.println("   Tipo: " + tipoColumna);
                        System.out.println("   Código de Tipo: " + tipoCodigo);
                        System.out.println("   Tamaño de Visualización: " + tamanoVisualizacion);
                        System.out.println("   Permite Nulos: " + permiteNulos);
                        System.out.println("   Precisión: " + precision);
                        System.out.println("   Escala: " + escala);
                        System.out.println();  // Línea en blanco para mayor claridad
                    }
                }
            }
        } catch (SQLException e) {
            System.out.println("Error de SQL: " + e.getMessage());
        }
    }
}
