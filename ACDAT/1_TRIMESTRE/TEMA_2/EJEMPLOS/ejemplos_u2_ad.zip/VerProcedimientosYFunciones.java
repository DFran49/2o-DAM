package jl;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class VerProcedimientosYFunciones {
    public static void main(String[] args) {
        try (Connection conexion = DriverManager.getConnection("jdbc:mariadb://localhost/mydb", "mydb", "password")) {
            DatabaseMetaData dbmd = conexion.getMetaData(); // Crear objeto DatabaseMetaData

            try (ResultSet proc = dbmd.getProcedures("mydb", null, null)) {
                boolean hayProcedimientos = false; // Variable para controlar si hay procedimientos

                while (proc.next()) {
                    hayProcedimientos = true; // Cambiar a verdadero si hay al menos un procedimiento
                    String proc_name = proc.getString("PROCEDURE_NAME");
                    String proc_type = proc.getString("PROCEDURE_TYPE");
                    System.out.printf("Nombre Procedimiento: %s - Tipo: %s %n", proc_name, proc_type);
                }

                if (!hayProcedimientos) // Mensaje si no se encontraron procedimientos
                    System.out.println("No se encontraron procedimientos en la base de datos.");
            }
        } catch (SQLException e) {
            System.out.println("Error de SQL: " + e.getMessage());
        }
    }
}
