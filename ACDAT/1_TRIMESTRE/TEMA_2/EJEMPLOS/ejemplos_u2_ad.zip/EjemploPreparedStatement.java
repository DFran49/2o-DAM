package jl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class EjemploPreparedStatement {
    public static void main(String[] args) {
        String url = "jdbc:mariadb://localhost/mydb";
        int idDepartamento = 2;
        String consultaSQL = "SELECT nombre, salario FROM empleados WHERE id_departamento > ?";

        try (Connection con = DriverManager.getConnection(url, "mydb", "password");
             PreparedStatement ps = con.prepareStatement(consultaSQL)) {
            ps.setInt(1, idDepartamento); // Establecer un valor de parámetro

            // Ejecutar la consulta
            try (ResultSet resultado = ps.executeQuery()) {
                while (resultado.next()) {
                    String nombre = resultado.getString("nombre");
                    double salario = resultado.getDouble("salario");
                    System.out.println("Nombre: " + nombre + ", Salario: " + salario);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error de SQL en la consulta: " + e.getMessage());
        }
    }
}
