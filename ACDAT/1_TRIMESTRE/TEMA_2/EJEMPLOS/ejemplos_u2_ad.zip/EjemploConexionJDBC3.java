package jl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class EjemploConexionJDBC3 {
    public static void main(String[] args) {
        String url = "jdbc:mariadb://localhost/mydb", usuario = "mydb", clave = "password";

        try (Connection conexion = DriverManager.getConnection(url, usuario, clave);
             Statement statement = conexion.createStatement()) {
            // Sentencia SQL para insertar un nuevo departamento
            String consulta = "INSERT INTO departamentos (id_departamento, nombre, localidad)"
                    + " VALUES (5, 'Compras', 'Granada')";

            statement.executeUpdate(consulta); // Ejecutar la sentencia

            System.out.println("La inserción se realizó correctamente.");
        } catch (SQLException e) {
            System.out.println("Error de SQL: " + e.getMessage());
        }
    }
}

