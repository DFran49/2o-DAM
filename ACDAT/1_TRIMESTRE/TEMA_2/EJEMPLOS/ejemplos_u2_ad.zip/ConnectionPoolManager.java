package jl;

import java.sql.Connection;
import java.sql.SQLException;
import org.apache.commons.dbcp2.BasicDataSource;

public class ConnectionPoolManager {
    private static final BasicDataSource dataSource;

    static {
        dataSource = new BasicDataSource(); // Configuración del pool de conexiones
        dataSource.setDriverClassName("org.mariadb.jdbc.Driver");
        dataSource.setUrl("jdbc:mariadb://localhost/mydb");
        dataSource.setUsername("mydb");
        dataSource.setPassword("password");

        // Configuración adicional del pool
        dataSource.setInitialSize(5); // Número inicial de conexiones en el pool
        dataSource.setMaxTotal(10); // Número máximo de conexiones en el pool
    }

    // Constructor privado para evitar instancias
    private ConnectionPoolManager() {
    }

    // Obtener una conexión del pool
    public static Connection getConnection() throws SQLException {
        return dataSource.getConnection();
    }

    // Devolver conexión al pool
    public static void closeConnection(Connection connection) throws SQLException {
        if (connection != null)
            connection.close();
    }

    // Proporciona información sobre el estado actual del pool de conexiones.
    public static String getPoolStatus() {
        return String.format("Conexiones activas: %d, Inactivas: %d, Totales: %d ",
                dataSource.getNumActive(), // Número de conexiones activas
                dataSource.getNumIdle(), // Número de conexiones inactivas
                dataSource.getMaxTotal());          // Número total de conexiones
    }
}
