package jl;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
/**
 * Clase que contine métodos para leer de forma segura por teclado. Cada método
 * realiza la validación del tipo de dato.
 *
 * @author jl
 * @version 1.0
 */
public class LecturaValidadaPorTeclado {
    // Para leer por teclado
    Scanner s;

    /**
     * Constructor vacío para la clase.
     * Crea el objeto para leer por teclado.
     */
    public LecturaValidadaPorTeclado() {
        s = new Scanner(System.in);
    }

    /**
     * Método que lee y valida un valor de tipo byte por teclado
     *
     * @param mensaje String con mensaje a mostrar al usuario
     * @return Valor numérico de tipo byte
     */
    public byte leerByte(String mensaje) {
        byte x = 0;
        boolean flag = true;
        do {
            try {
                x = Byte.parseByte((String) validar(1, mensaje, "Ingresa un valor de tipo byte."));
                flag = false;
            } catch (NumberFormatException e) {
                System.out.println("Valor byte fuera del rango.");
            }
        } while (flag);

        return x;
    }

    /**
     * Método que lee y valida un valor de tipo short por teclado
     *
     * @param mensaje String con mensaje a mostrar al usuario
     * @return Valor numérico de tipo short
     */
    public short leerShort(String mensaje) {
        short x = 0;
        boolean flag = true;
        do {
            try {
                x = Short.parseShort((String) validar(2, mensaje, "Ingresa un valor de tipo short."));
                flag = false;
            } catch (NumberFormatException e) {
                System.out.println("Valor short fuera del rango.");
            }
        } while (flag);

        return x;
    }

    /**
     * Método que lee y valida un valor de tipo int por teclado
     *
     * @param mensaje String con mensaje a mostrar al usuario
     * @return Valor numérico de tipo int
     */
    public int leerInt(String mensaje) {
        int x = 0;
        boolean flag = true;
        do {
            try {
                x = Integer.parseInt((String) validar(3, mensaje, "Ingresa un valor int."));
                flag = false;
            } catch (NumberFormatException e) {
                System.out.println("Valor int fuera del rango.");
            }
        } while (flag);

        return x;
    }

    /**
     * Método que lee y valida un valor de tipo long por teclado
     *
     * @param mensaje String con mensaje a mostrar al usuario
     * @return Valor numérico de tipo long
     */
    public long leerLong(String mensaje) {
        long x = 0;
        boolean flag = true;
        do {
            try {
                x = Long.parseLong((String) validar(4, mensaje, "Ingresa un valor long."));
                flag = false;
            } catch (NumberFormatException e) {
                System.out.println("Valor long fuera del rango.");
            }
        } while (flag);

        return x;
    }

    /**
     * Método que lee y valida un valor de tipo char por teclado
     *
     * @param mensaje String con mensaje a mostrar al usuario
     * @return Valor numérico de tipo char
     */
    public String leerChar(String mensaje) {
        return (String) validar(5, mensaje, "Ingresa un solo caracter.");
    }

    /**
     * Método que lee y valida un valor de tipo cadena por teclado. Únicamente
     * permite la lectura de letras, números, _ y espacios.
     *
     * @param mensaje String con mensaje a mostrar al usuario
     * @return Cadena de texto que contiene letras, números, _ y espacios
     */
    public String leerString(String mensaje) {
        return (String) validar(6, mensaje,
                "Ingresa una cadena de caracteres que contenga letras, números, _ o espacios.");
    }

    /**
     * Método que lee y valida un valor de tipo booleano por teclado
     *
     * @param mensaje String con mensaje a mostrar al usuario
     * @return Valor booleano (true o false)
     */
    public String leerBoolean(String mensaje) {
        return (String) validar(7, mensaje, "Ingresa un valor booleano: true o false.");
    }

    /**
     * Método que lee y valida un valor de tipo float por teclado
     *
     * @param mensaje String con mensaje a mostrar al usuario
     * @return Valor numérico de tipo float
     */
    public float leerFloat(String mensaje) {
        float x = 0;
        boolean flag = true;
        do {
            try {
                x = Float.parseFloat((String) validar(8, mensaje, "Ingresa un valor float."));
                flag = false;
            } catch (NumberFormatException e) {
                System.out.println("Valor float fuera del rango.");
            }
        } while (flag);

        return x;
    }

    /**
     * Método que lee y valida un valor de tipo double por teclado
     *
     * @param mensaje String con mensaje a mostrar al usuario
     * @return Valor numérico de tipo double
     */
    public double leerDouble(String mensaje) {
        double x = 0;
        boolean flag = true;
        do {
            try {
                x = Double.parseDouble((String) validar(9, mensaje, "Ingresa un valor double."));
                flag = false;
            } catch (NumberFormatException e) {
                System.out.println("Valor double fuera del rango.");
            }
        } while (flag);

        return x;
    }

    /**
     * Método que lee y valida un teléfono por teclado
     *
     * @param mensaje String con mensaje a mostrar al usuario
     * @return Cadena de texto con formato teléfono 000 00 00 00
     */
    public String leerTelefono(String mensaje) {
        return (String) validar(10, mensaje, "Ingresa un teléfono válido con formato 000 00 00 00.");
    }

    /**
     * Método que lee y valida una fecha por teclado
     *
     * @param mensaje String con mensaje a mostrar al usuario
     * @return Cadena de texto con formato fecha dd-mm-YYYY
     */
    public String leerFecha(String mensaje) {
        return (String) validar(11, mensaje, "Ingresa una fecha válida con formato dd-mm-yyyy.");
    }

    /**
     * Método que lee y valida un NIF por teclado
     *
     * @param mensaje String con mensaje a mostrar al usuario
     * @return Cadena de texto con formato NIF 00000000-A
     */
    public String leerNIF(String mensaje) {
        return (String) validar(12, mensaje, "Ingresa un NIF válido con formato 00000000-A.");
    }

    /**
     * Método que lee y valida un e-mail por teclado
     *
     * @param mensaje String con mensaje a mostrar al usuario
     * @return Cadena de texto con formato e-mail aaaa@bbbbb.ccc
     */
    public String leerEMail(String mensaje) {
        return (String) validar(13, mensaje, "Ingresa un e-mail válido con formato aaaaa@bbbbb.ccc");
    }

    /**
     * Método que permite validad una cadena de caracteres según el tipo indicado
     *
     * @param v          Tipo del dato a validar: 1:byte, 2: short, 3:int, 4:long,
     *                   5:char, 6:cadena de texto, 7:booleano, 8:float, 9:double,
     *                   10:teléfono,
     *                   11:fecha, 12:nif y 13:e-mail
     * @param mensaje    String con mensaje a mostrar al usuario
     * @param validacion String con mensaje sobre formato del campo a validar
     * @return Object Objeto validado
     */
    private Object validar(int v, String mensaje, String validacion) {
        boolean flag = true;
        CharSequence ob;
        Pattern pat = null;
        Matcher mat = null;

        switch (v) {
            case 1, 2, 3, 4 -> // byte, short, int y long
                pat = Pattern.compile("^[+-]?\\d+$");
            case 5 -> // char
                pat = Pattern.compile("^.$");
            case 6 -> // Cadena con letras, números, _ y espacios
                pat = Pattern.compile("^[a-zA-Z0-9_ ]+$");
            case 7 -> // boolean
                pat = Pattern.compile("^true|false$");
            case 8, 9 -> // float y double
                pat = Pattern.compile("[+-]?(\\d+|\\d+\\.\\d+|\\.\\d+|\\d+\\.)([eE]\\d+)?");
            case 10 -> // Teléfono
                pat = Pattern.compile("^[0-9]{3} [0-9]{2} [0-9]{2} [0-9]{2}$");
            case 11 -> // Fecha
                pat = Pattern.compile("^(3[01]|[12][0-9]|0[1-9])/(1[0-2]|0[1-9])/[0-9]{4}$");
            case 12 -> // NIF
                pat = Pattern.compile("^[0-9]{8}-[a-zA-Z]$");
            case 13 -> // E-mail
                pat = Pattern.compile("^[\\w!#$%&’*+/=?`{|}~^-]+(?:\\.[\\w!#$%&’*+/=?`{|}~^-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$");
        }

        do {
            System.out.print(mensaje + ": ");
            ob = s.nextLine();
            if (pat != null)
                mat = pat.matcher(ob);
            if (mat != null && mat.matches()) 
                flag = false;
        } while (flag);

        return ob;
    }
}
