package jl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionManager {

    private static final String URL = "jdbc:mariadb://localhost:3306/mydb";
    private static final String USER = "mydb";
    private static final String PASSWORD = "password";

    // Constructor privado para evitar instancias
    private ConnectionManager() {
    }

    public static Connection getConnection() throws SQLException { // Obtener conexión a la BD
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    public static void closeConnection(Connection connection) throws SQLException { // Cerrar conexión
        if (connection != null) {
            connection.close();
        }
    }
}
