package jl;

import java.sql.Connection;
import java.sql.SQLException;

public class EjemploConexionJDBC2 {
    public static void main(String[] args) {
        Connection conexion = null;

        try {
            conexion = ConnectionManager.getConnection(); // Obtener la conexión

            // Realizar operaciones con la conexión a la BD
        } catch (SQLException e) {
            System.out.println("Error al conectar con la BD: " + e.getMessage());
        } finally {
            try {
                ConnectionManager.closeConnection(conexion); // Cerrar la conexión
            } catch (SQLException e) {
                System.out.println("Error al desconectar de la BD: " + e.getMessage());
            }
        }
    }
}

