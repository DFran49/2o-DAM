package jl;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class EjemplogetColumns {
    public static void main(String[] args) {
        try (Connection con = DriverManager.getConnection("jdbc:mariadb://localhost/mydb", "mydb", "password")) {
            DatabaseMetaData dbmd = con.getMetaData(); // Crear objeto DatabaseMetaData

            System.out.println("===================================");
            System.out.println("=   COLUMNAS TABLA DEPARTAMENTOS  =");
            System.out.println("===================================");

            try (ResultSet columnas = dbmd.getColumns("mydb", null, "departamentos", null)) {
                while (columnas.next()) {
                    String nombCol = columnas.getString("COLUMN_NAME");
                    String tipoCol = columnas.getString("TYPE_NAME");
                    int tamCol = columnas.getInt("COLUMN_SIZE"); // Convertido a int para mejor manejo
                    String nula = columnas.getString("IS_NULLABLE");

                    System.out.printf("Columna: %s, Tipo: %s, Tamaño: %d, ¿Puede ser nula?: %s %n",
                            nombCol, tipoCol, tamCol, nula);
                }
            } catch (SQLException e) {
                System.out.println("Error al obtener las columnas de la tabla 'departamentos': " + e.getMessage());
            }
        } catch (SQLException e) {
            System.out.println("Error de SQL: " + e.getMessage());
        }
    }
}
