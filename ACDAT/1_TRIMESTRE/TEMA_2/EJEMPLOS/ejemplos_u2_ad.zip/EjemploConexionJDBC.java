package jl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class EjemploConexionJDBC {
    public static void main(String[] args) {
        String url = "jdbc:mariadb://localhost:3306/mydb";
        String usuario = "mydb", clave = "password";

        try (Connection conexion = DriverManager.getConnection(url, usuario, clave)) {
            // Realizar operaciones con la conexión a la BD
        } catch (SQLException e) {
            System.out.println("Error al conectar con la BD: " + e.getMessage());
        }
    }
}

