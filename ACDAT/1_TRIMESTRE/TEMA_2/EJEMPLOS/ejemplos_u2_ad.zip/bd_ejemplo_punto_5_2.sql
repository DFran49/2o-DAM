CREATE TABLE departamentos (
    id_departamento TINYINT PRIMARY KEY,
    nombre VARCHAR(15),
    localidad VARCHAR(15)
);
INSERT INTO departamentos VALUES (1,'Contabilidad','Sevilla'), (2,'Investigación','Madrid'),
          (3,'Ventas','Barcelona'), (4,'Producción','Granada');
CREATE TABLE empleados (
    id_empleado SMALLINT PRIMARY KEY,
    nombre VARCHAR(40),
    oficio VARCHAR(10),
    fecha_alta DATE,
    salario DECIMAL(7, 2),
    comision DECIMAL(6, 2),
    id_departamento TINYINT NOT NULL,
    FOREIGN KEY(id_departamento) REFERENCES departamentos(id_departamento)
);
INSERT INTO empleados VALUES (7369, 'Luis Sánchez', 'EMPLEADO', '2010/12/17', 1040, NULL, 2),
       (7499, 'Carlos Arroyo', 'VENDEDOR', '2010/02/20', 1500, 390, 3),
       (7521, 'María Sala', 'VENDEDOR', '2011/02/22', 1625, 650, 3),
       (7566, 'Luis Jiménez', 'DIRECTOR', '2011/04/02', 2900, NULL, 2),
       (7654, 'José Martín', 'VENDEDOR', '2011/09/29', 1600, 1020, 3),
       (7698, 'Enrique Negro', 'DIRECTOR', '2011/05/01', 3005, NULL, 3),
       (7782, 'Javier Cerezo', 'DIRECTOR', '2011/06/09', 2885, NULL, 1),
       (7788, 'Álvaro Gil', 'ANALISTA', '2011/11/09', 3000, NULL, 2),
       (7839, 'Barbara Rey', 'PRESIDENTE', '2011/11/17', 4100, NULL, 1),
       (7844, 'Luis Tovar', 'VENDEDOR', '2011/09/08', 1350, 0, 3),
       (7876, 'Pepe Alonso', 'EMPLEADO', '2011/09/23', 1430, NULL, 2),
       (7900, 'Francisco Jimeno', 'EMPLEADO', '2011/12/03', 1335, NULL, 3),
       (7902, 'Luisa Fernández', 'ANALISTA', '2011/12/03', 3000, NULL, 2),
       (7934, 'Nicolás Muñoz', 'EMPLEADO', '2012/01/23', 1690, NULL,1);
