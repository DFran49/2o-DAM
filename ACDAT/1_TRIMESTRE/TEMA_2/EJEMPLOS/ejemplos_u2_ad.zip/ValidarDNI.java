package jl;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ValidarDNI {
    public static void validarDNI() {
        String dni;
        Pattern pat;
        Matcher mat;
        Scanner sc = new Scanner(System.in);

        System.out.print("Introduce tu DNI (Formato 00000000-A): ");
        dni = sc.nextLine();
        pat = Pattern.compile("[0-9]{8}-[a-zA-Z]");
        mat = pat.matcher(dni);
        if (mat.find())
            System.out.println("Correcto!! " + dni);
        else
            System.out.println("El DNI está mal " + dni);
    }

    public static void main(String[] arg) {
        validarDNI();
    }
}

