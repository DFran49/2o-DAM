package jl;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.CallableStatement;
import java.sql.Types;
import java.sql.SQLException;

public class CallableStatementEjemplo {
    public static void main(String[] args) {
        try (Connection con = DriverManager.getConnection("jdbc:mariadb://localhost/mydb", "mydb", "password");
             CallableStatement cs = con.prepareCall("{call obtener_nombre_localidad_departamento(?, ?, ?)}")) {
            // Registrar el parámetro de entrada
            cs.setInt(1, 2); // Parámetro de entrada: ID del departamento
            // Registrar los parámetros de salida
            cs.registerOutParameter(2, Types.VARCHAR); // Par. salida: nombre del departamento
            cs.registerOutParameter(3, Types.VARCHAR); // Par. salida: localidad

            // Ejecutar el procedimiento almacenado
            cs.execute();

            // Recuperar y procesar los valores de los parámetros de salida
            String nombre = cs.getString(2);
            String localidad = cs.getString(3);

            // Validar los resultados de salida
            if (nombre != null && localidad != null)
                System.out.println("El resultado es: " + nombre + " - " + localidad);
            else
                System.out.println("No se pudo obtener el nombre o la localidad.");
        } catch (SQLException e) {
            System.out.println("Error al ejecutar el procedimiento almacenado: " + e.getMessage());
        }
    }
}

