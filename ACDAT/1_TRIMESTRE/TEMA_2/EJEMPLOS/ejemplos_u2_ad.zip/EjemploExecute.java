package jl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class EjemploExecute {
    public static void main(String[] args) {
        String url = "jdbc:mariadb://localhost/mydb";

        try (Connection conexion = DriverManager.getConnection(url, "mydb", "password");
             Statement statement = conexion.createStatement()) {
            String consultaSQL = "SELECT * FROM empleados2";
            
            // Ejecutar la sentencia SQL y verificar si devuelve un conjunto de resultados
            boolean tieneResultados = statement.execute(consultaSQL);
            if (tieneResultados) { // Si tiene resultados, procesarlos
                try (ResultSet res = statement.getResultSet()) {
                    while (res.next()) {
                        String nombre = res.getString("nombre");
                        double salario = res.getDouble("salario");
                        System.out.println("Nombre: " + nombre + ", Salario: " + salario);
                    }
                }
            } else {
                System.out.println("La sentencia no devuelve resultados.");
            }
        } catch (SQLException e) {
            System.out.println("Error de SQL: " + e.getMessage());
        }
    }
}


