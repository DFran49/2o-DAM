package jl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class EjemploUsoHikariCPConnectionPool {
    public static void main(String[] args) {
        Connection connection1 = null, connection2 = null, connection3 = null;

        try {
            // Mostrar el estado del pool antes de obtener varias conexiones
            System.out.println("Estado del pool antes de establecer tres conexiones:");
            System.out.println(HikariCPConnectionPool.getPoolStatus());

            // Establecer varias conexiones del pool
            connection1 = HikariCPConnectionPool.getConnection();
            connection2 = HikariCPConnectionPool.getConnection();
            connection3 = HikariCPConnectionPool.getConnection();

            // Mostrar el estado del pool después de obtener varias conexiones
            System.out.println("Estado del pool tras establecer tres conexiones:");
            System.out.println(HikariCPConnectionPool.getPoolStatus());

            // Ejecutar una consulta simple con la primera conexión
            ejecutarConsulta(connection1);

            // Cerrar la conexión y devolverla al pool
            HikariCPConnectionPool.closeConnection(connection1);

            // Mostrar el estado del pool tras ejecutar una consulta
            System.out.println("Estado del pool tras ejecutar la consulta en la primera conexión:");
            System.out.println(HikariCPConnectionPool.getPoolStatus());
        } catch (SQLException e) {
            System.err.println("Error al interactuar con la base de datos: " + e.getMessage());
        } finally {
            try { // Cerrar las conexiones y devolverlas al pool
                HikariCPConnectionPool.closeConnection(connection2);
                HikariCPConnectionPool.closeConnection(connection3);

                // Mostrar el estado del pool después de cerrar las conexiones
                System.out.println("Estado del pool tras cerrar las conexiones:");
                System.out.println(HikariCPConnectionPool.getPoolStatus());
            } catch (SQLException e) {
                System.err.println("Error al cerrar las conexiones: " + e.getMessage());
            }
        }
    }

    // Método auxiliar para ejecutar una consulta con una conexión
    private static void ejecutarConsulta(Connection connection) throws SQLException {
        String query = """
            SELECT e.id_empleado, e.nombre AS empleado, e.oficio, e.salario, d.nombre AS departamento, d.localidad
            FROM empleados e
            JOIN departamentos d ON e.id_departamento = d.id_departamento
        """;

        try (PreparedStatement stmt = connection.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) { // Procesar los resultados
                int idEmpleado = rs.getInt("id_empleado");
                String nombreEmpleado = rs.getString("empleado");
                String oficio = rs.getString("oficio");
                double salario = rs.getDouble("salario");
                String nombreDepartamento = rs.getString("departamento");
                String localidad = rs.getString("localidad");

                System.out.printf("Empleado: %d, Nombre: %s, Oficio: %s, Salario: %.2f, Departamento: %s, Localidad: %s%n",
                        idEmpleado, nombreEmpleado, oficio, salario, nombreDepartamento, localidad);
            }
        }
    }
}
