package jl;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.CallableStatement;
import java.sql.Types;
import java.sql.SQLException;

public class LlamadaFuncionEjemplo {
    public static void main(String[] args) {
        String url = "jdbc:mariadb://localhost/mydb", usuario = "mydb", clave = "password";

        try (Connection con = DriverManager.getConnection(url, usuario, clave);
             CallableStatement cs = con.prepareCall("{? = call obtener_nombre_departamento( ? )}")) {
            cs.registerOutParameter(1, Types.VARCHAR); // Registrar el parámetro de salida
            cs.setInt(2, 2); // Establecer el parámetro de entrada

            cs.execute(); // Ejecutar la función

            String nombre = cs.getString(1); // Obtener el resultado
            if (nombre != null)
                System.out.println("El nombre del departamento es: " + nombre);
            else
                System.out.println("No se encontró un nombre para el departamento.");
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
            System.out.println("Código SQL: " + e.getErrorCode());
            System.out.println("Estado: " + e.getSQLState());
        }
    }
}
