package jl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class VulnerableApp {
    public static void main(String[] args) {
        String userInput = "'; DROP TABLE usuarios; --"; // Entrada maliciosa del usuario

        // Construcción de la consulta sin validar la entrada del usuario
        String query = "SELECT * FROM usuarios WHERE nombre = '" + userInput + "'";
        try (Connection connection = DriverManager.getConnection("jdbc:mariadb://localhost/base_de_datos",
            "usuario", "contraseña"); Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query)) {
            // Procesamiento de los resultados
            while (resultSet.next()) {
                System.out.println("Nombre: " + resultSet.getString("nombre"));
                // Otros campos...
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
