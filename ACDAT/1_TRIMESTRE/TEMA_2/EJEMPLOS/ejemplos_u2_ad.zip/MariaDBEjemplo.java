package jl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MariaDBEjemplo {
    public static void main(String[] args) {
        // Datos de conexión a la BD mydb alojada en un servidor MariaDB
        String jdbcURL = "jdbc:mariadb://localhost:3306/mydb"; // Puerto 3306 por defecto, puede no ponerse
        // String jdbcURL = "jdbc:mysql://localhost:3306/mydb"; --> Para MySQL
        String usuario = "mydb", clave = "password";
        // Declaraciones JDBC
        Connection conexion = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            Class.forName("org.mariadb.jdbc.Driver"); // Paso 1: Cargar el driver JDBC de MariaDB – NO NECESARIO
            // Class.forName("com.mysql.cj.jdbc.Driver"); --> Para MySQL

            // Paso 2: Establecer la conexión
            conexion = DriverManager.getConnection(jdbcURL, usuario, clave);

            statement = conexion.createStatement(); // Paso 3: Crear una declaración

            // Paso 4: Preparar y ejecutar una consulta SQL
            String sqlQuery = "SELECT * FROM departamentos";
            resultSet = statement.executeQuery(sqlQuery);

            // Paso 5: Procesar los resultados. Se repite el bucle mientras haya registros en el ResultSet
            while (resultSet.next())
                System.out.println("ID: " + resultSet.getInt("id_departamento") + ", Nombre: " +
                        resultSet.getString("nombre") + ", Ciudad: " + resultSet.getString("localidad"));
        } catch (ClassNotFoundException e) { // Puede causarla Class.forName(...)
            System.out.println("Error al cargar el controlador JDBC: " + e.getMessage());
        } catch (SQLException e) { // Puede causarla el resto de métodos SQL
            System.out.println("Error de SQL: " + e.getMessage());
        } finally {
            try { // Paso 6: Cerrar la conexión y liberar recursos, en orden inverso al que se crean
                if (resultSet != null)
                    resultSet.close(); // Cerrar ResultSet
                if (statement != null)
                    statement.close(); // Cerrar Statement
                if (conexion != null)
                    conexion.close(); // Cerrar conexión
            } catch (SQLException e) { // Puede causarla el cierre y liberación de los recursos
                System.out.println("Error al cerrar la conexión y liberar recursos: " + e.getMessage());
            }
        }
    }
}

