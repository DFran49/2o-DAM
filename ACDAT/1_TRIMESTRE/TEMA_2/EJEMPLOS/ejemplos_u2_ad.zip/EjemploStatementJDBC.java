package jl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class EjemploStatementJDBC {
    public static void main(String[] args) {
        String url = "jdbc:mariadb://localhost/mydb";
        String usuario = "mydb", clave = "password";

        try (Connection con = DriverManager.getConnection(url, usuario, clave);
             Statement stm = con.createStatement()) {
            // Eliminar la tabla si ya existe para evitar errores
            String eliminarTabla = "DROP TABLE IF EXISTS empleados2";
            stm.executeUpdate(eliminarTabla);

            // Crear una tabla
            String tabla = "CREATE TABLE empleados2 (id INT PRIMARY KEY, nombre VARCHAR(255), salario DOUBLE)";
            stm.executeUpdate(tabla);

            // Insertar datos
            String insertar = "INSERT INTO empleados2(id, nombre, salario) VALUES (1, 'Juan', 50000)";
            stm.executeUpdate(insertar); 

            // Consulta SELECT
            String consulta = "SELECT nombre, salario FROM empleados2 WHERE salario > 40000";
            ResultSet res = stm.executeQuery(consulta);

            // Procesar el resultado de la consulta
            while (res.next())
                System.out.println("Nombre: " + res.getString("nombre") + ", Salario: " + res.getDouble("salario"));

            // Cerrar ResultSet explícitamente para evitar posibles fugas de memoria
            res.close();

            // Ejecutar varias consultas en lote
            stm.addBatch("INSERT INTO empleados2 (id, nombre, salario) VALUES (2, 'María', 55000)");
            stm.addBatch("INSERT INTO empleados2 (id, nombre, salario) VALUES (3, 'Pedro', 60000)");
            int[] filasAfectadas = stm.executeBatch();

            // Informar cuántas filas se afectaron en total con el batch
            int totalFilasAfectadas = 0;
            for (int filas : filasAfectadas)
                totalFilasAfectadas += filas;
            System.out.println("Número total de filas afectadas por el batch: " + totalFilasAfectadas);
        } catch (SQLException e) {
            System.out.println("Error de SQL: " + e.getMessage());
        }
    }
}

