package dam.mobiles.proyecto5.modelo

data class Detalle(
    var color: String,
    val tallas:List<String>
)
